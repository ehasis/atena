/* this demo of mjpga shows what is need to do to play a movie */

//#define DEBUGMODE

#include <string.h>
#include <allegro.h>
// include this after allegro
#include "mjpga.h"


// some macros...
#define MAX_ARQ		512
#define CF1				makecol(0, 0, 0)				// cor do texto
#define CB0				makecol(0, 128, 192)			// cor do fundo da tela
#define CB1				makecol(222, 222, 222)		// cor do fundo do di�logo
#define CB2				makecol(255, 255, 255)		// cor do fundo do bot�o e do texto


// show intro
void intro(void);
// callback function to play_movie(), here we can stop the movie at any time
// and toggle fullscreen
int controle(void);


// main function
int main(void)
{
	char file[MAX_ARQ];
	int ok;
	int gfx = GFX_AUTODETECT_WINDOWED, w = 640, h = 480, bpp = 16;

	allegro_init();
	install_keyboard();
	install_timer();
	install_mouse();
	install_sound(DIGI_AUTODETECT, MIDI_NONE, "");
	if(set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) < 0)
		set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0);
	set_palette(desktop_palette);
	clear_to_color(screen, CB0);

	// choose the display driver
	ok = 0;
	do {
		ok = gfx_mode_select_ex(&gfx, &w, &h, &bpp);
		if(!ok)
			return EXIT_SUCCESS;
		if(bpp == 8) {
			alert("Choose a color depth different of 8 bpp", "", "", "OK", NULL, 13, 0);
			ok = 0;
		}
	} while(!ok);

	// set graphics mode
	set_color_depth(bpp);
	if(set_gfx_mode(gfx, w, h, 0, 0)) {
		set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
		allegro_message("Error!\n%s", allegro_error);
		return EXIT_FAILURE;
	}
	clear_to_color(screen, CB0);

	// show intro
	intro();

	// load from a config file the initial dir
	push_config_state();
	set_config_file("./mjpgdemo.cfg");
	strcpy(file, get_config_string(NULL, "ultimo_diretorio", "./"));
	pop_config_state();

	// choose the movie to see
	do {
		ok = file_select_ex("Choose the datafile or the avi", file, "AVI;DAT", MAX_ARQ, SCREEN_W*0.8, SCREEN_H*0.8);
		if(ok) {
			// play the movie
			clear(screen);
			if(play_movie(file, screen, controle)) {
				alert("Error", "", "", "OK", NULL, 13, 0);
			}
			clear_to_color(screen, CB0);
		}
	} while(ok);
	push_config_state();
	set_config_file("./mjpgdemo.cfg");
	set_config_string(NULL, "ultimo_diretorio", file);
	pop_config_state();

	return 0;
}
END_OF_MAIN();


// show intro
void intro(void)
{
	char inst[] = "MJpgDemo for MJpgAlleg " MJPGA_VERSION_STR "\n\n"
		"Play a datafile or a avi, supporting jpg's (dat only) or XviD frames, "
		"with audio in pcm uncompressed or mp3 format\n\n"
		"Alt+0     -> Normal mode\n"
		"Alt+1     -> Toggle center mode\n"
		"Alt+2     -> Toggle half mode\n"
		"Alt+3     -> Toggle double mode\n"
		"Alt+ENTER -> Toggle full Screen mode\n"
		"ESC       -> Stop playing\n\n\n"
		"Copyright � 2002 Dudaskank\n"
		"http://br.geocities.com/dudaskank\n"
		"dudaskank@yahoo.com";
	DIALOG d[] = {
		{ d_shadow_box_proc, 0, 0, SCREEN_W*0.7, SCREEN_H*0.7, CF1, CB1, 0, 0, 0, 0, NULL, NULL, NULL },
		{ d_textbox_proc, 10, 10, SCREEN_W*0.7-20, SCREEN_H*0.7-50, CF1, CB2, 0, 0, 0, 0, (void *)inst, NULL, NULL },
		{ d_button_proc, 10, SCREEN_H*0.7-30, SCREEN_W*0.7-20, 20, CF1, CB2, 13, D_EXIT, 0, 0, "OK", NULL, NULL },
		{ NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL }
	};
	centre_dialog(d);
	popup_dialog(d, -1);
}


// callback function to play_movie(), here we can stop the movie at any time
// and toggle the display modes
int controle(void)
{
	static int tecla_ant[MJPGAM_TOTAL_MODES] = {
		0, 0, 0, 0, 0
	};
	int alt_teclas[MJPGAM_TOTAL_MODES] = {
		KEY_0,
		KEY_ENTER,
		KEY_1,
		KEY_2,
		KEY_3
	};
	int i;

	for(i = 0; i < MJPGAM_TOTAL_MODES; i++) {
		if(key[alt_teclas[i]] && key_shifts & KB_ALT_FLAG) {
			if(!tecla_ant[i]) {
				if(get_mode_movie() != i) {
					set_mode_movie(i);
					clear(screen);
				}
				else {
					if(get_mode_movie() != MJPGAM_NORMAL) {
						set_mode_movie(MJPGAM_NORMAL);
						clear(screen);
					}
				}
				tecla_ant[i] = 1;
			}
		}
		else {
			tecla_ant[i] = 0;
		}
	}

	return key[KEY_ESC] != 0;
}
