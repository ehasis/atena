/*! \addtogroup mjpga MJpgAlleg
 *  @{
 */

#ifndef MJPGALLEG_H
#define MJPGALLEG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <allegro.h>
#include "mjpga/jpgalleg.h"
#include "mjpga/avi.h"
#include "mjpga/mjpgadat.h"
#include "mjpga/mjpgaavi.h"
#include "mjpga/audio.h"


#define MJPGA_VERSION				2
#define MJPGA_SUB_VERSION			3
#define MJPGA_VERSION_STR			"2.3"
#define MJPGA_DATE_STR				"20030404"
#define MJPGA_DATE					20030404		/* yyyymmdd */


/* macros */
/*! \def MJPGAT_DAT
 *  \brief Type datafile */
#define MJPGAT_DAT		AL_ID('D', 'A', 'T', ' ')
/*! \def MJPGAT_AVI
 *  \brief Type avi file */
#define MJPGAT_AVI		AL_ID('A', 'V', 'I', ' ')
/*! \def MJPGAST_JPG
 *  \brief Subtype jpg (only to datafiles) */
#define MJPGAST_JPG		AL_ID('J', 'P', 'G', ' ')
/*! \def MJPGAST_M4V
 *  \brief Subtype m4v (only to datafiles) */
#define MJPGAST_M4V		AL_ID('M', '4', 'V', ' ')
/*! \def MJPGAST_XVID
 *  \brief Subtype XviD (only to avi files) */
#define MJPGAST_XVID		AL_ID('X', 'V', 'I', 'D')
/*! \def MJPGAST_DIVX
 *  \brief Subtype DivX (only to avi files) */
#define MJPGAST_DIVX		AL_ID('D', 'I', 'V', 'X')

/*! \def MJPGAM_NORMAL
 *  \brief Display mode normal */
#define MJPGAM_NORMAL	0
/*! \def MJPGAM_FULL
 *  \brief Display mode full screen */
#define MJPGAM_FULL		1
/*! \def MJPGAM_CENTER
 *  \brief Display mode center */
#define MJPGAM_CENTER	2
/*! \def MJPGAM_HALF
 *  \brief Display mode half size */
#define MJPGAM_HALF		3
/*! \def MJPGAM_DOUBLE
 *  \brief Display mode double size */
#define MJPGAM_DOUBLE	4

/*! \def MJPGAM_TOTAL_MODES
 *  \brief Numer of display modes */
#define MJPGAM_TOTAL_MODES		(MJPGAM_DOUBLE + 1)



/* types */
/*!
 *  \brief The main struct of MJpgAlleg, it contain all information to play
 *  the movie
*/
typedef struct MJPGA_MOVIE {
	int type;				/*!< \brief type of the movie (datafile, avi) */
	int subtype;			/*!< \brief format of video frames (jpg/m4v or xvid/divx) */
	void *movie;			/*!< \brief pointer to movie struct (DATAFILE * or AVI_MOVIE *) */
	MJPGA_AUDIO *audio;	/*!< \brief pointer to audio struct */
	float fps;				/*!< \brief frames per second */
	int size;				/*!< \brief number of frames */
	int frame;				/*!< \brief current frame */
	int last_frame;		/*!< \brief last frame rendered (for use with divx/xvid) */
	int xvid, yvid;		/*!< \brief width and height of the movie */
	char desc[256];		/*!< \brief description of the movie */
	unsigned char mode;	/*!< \brief mode of the movie (== 0 normal, != 0 fullscreen) */
} MJPGA_MOVIE;


/* prototypes */
void init_movie(void);
int play_movie(const char *file, BITMAP *bmp, int (*callback)());
int open_movie(const char *file);
void close_movie(void);
int update_movie_frame(void);
void set_mode_movie(unsigned char mode);
unsigned char get_mode_movie(void);


/* global vars */
extern MJPGA_MOVIE *the_movie;
extern volatile int timer_movie;


#ifdef __cplusplus
}
#endif

#endif // MJPGALLEG_H

/*! @} */
