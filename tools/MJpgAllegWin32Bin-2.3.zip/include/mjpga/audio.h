/*! \addtogroup audio Audio - functions, types and macros
 *  @{
 */

#ifndef AUDIO_H
#define AUDIO_H

#include <allegro.h>
//#include "mjpga.h"
#include "almp3.h"		/* for mp3 support */

#ifdef __cplusplus
extern "C" {
#endif


/*! \def MJPGA_AUDIO_PCM
 *  \brief PCM uncompressed */
#define MJPGA_AUDIO_PCM				DAT_SAMPLE
/*! \def MJPGA_AUDIO_PCMSTREAM
 *  \brief Streaming of PCM uncompressed */
#define MJPGA_AUDIO_PCMSTREAM		AL_ID('S', 'T', 'R', 'M')
/*! \def MJPGA_AUDIO_MP3
 *  \brief MP3 */
#define MJPGA_AUDIO_MP3				AL_ID('M', 'P', '3', ' ')
/*! \def MJPGA_AUDIO_MP3STREAM
 *  \brief Streaming of MP3 */
#define MJPGA_AUDIO_MP3STREAM		AL_ID('M', 'P', '3', 'S')

/*! \def AVI_AUDIO_PCM
 *  \brief FCC of PCM uncompressed in avi file */
#define AVI_AUDIO_PCM				0x01
/*! \def AVI_AUDIO_MP3
 *  \brief FCC of MP3 in avi file */
#define AVI_AUDIO_MP3				0x55


/* types */

struct MJPGA_MOVIE;

/*! \brief Union to mantain all the supported audio formats
*/
union audio_formats {
	SAMPLE *sample;					/*!< \brief PCM uncompressed */
	AUDIOSTREAM *audiostream;		/*!< \brief Streaming PCM uncompressed */
	ALMP3_MP3 *mp3;					/*!< \brief MP3 */
	ALMP3_MP3STREAM *mp3stream;	/*!< \brief Streaming MP3 */
};


/*! \brief The struct containing all information to play the audio
*/
typedef struct MJPGA_AUDIO{
	int type;							/*!< \brief type of the audio */
	union audio_formats af;			/*!< \brief audio format */
	void *audio_data;					/*!< \brief buffer, used in mp3 and mp3stream */
	int len_data;						/*!< \brief lenght, in bytes, of audio_data */
	int audio_frame;					/*!< \brief current audio frame, used in avi files */
	int pos_frame;						/*!< \brief current position in that frame, used in avi files */
	int freq;							/*!< \brief frequency (Hz) of audio */
	short int bits;					/*!< \brief bits of audio */
	short int channels;				/*!< \brief number of channels */
} MJPGA_AUDIO;


int mjpga_audio_open(struct MJPGA_MOVIE *mjpga);
int mjpga_audio_poll(struct MJPGA_MOVIE *mjpga);
void mjpga_audio_destroy(struct MJPGA_MOVIE *mjpga);
void mjpga_audio_play(struct MJPGA_MOVIE *mjpga);


#ifdef __cplusplus
}
#endif

#endif // AUDIO_H

/*! @} */
