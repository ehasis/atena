/*! \addtogroup avi
 *  @{
 */


#ifndef AVI_H
#define AVI_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdio.h>
#include <allegro.h>


/* macros */
//fcc's
/*! \def FCC_RIFF
 *  \brief First code in the avi
*/
#define FCC_RIFF			AL_ID('F', 'F', 'I', 'R')
/*! \def FCC_AVI
 *  \brief After 'RIFF', this is need to be a valid avi file
*/
#define FCC_AVI			AL_ID(' ', 'I', 'V', 'A')
/*! \def FCC_LIST
 *  \brief Start of the list of chunks
*/
#define FCC_LIST			AL_ID('T', 'S', 'I', 'L')
/*! \def FCC_hdrl
 *  \brief Start the list of headers
*/
#define FCC_hdrl			AL_ID('l', 'r', 'd', 'h')
/*! \def FCC_avih
 *  \brief Main avi header
*/
#define FCC_avih			AL_ID('h', 'i', 'v', 'a')
/*! \def FCC_strl
 *  \brief List of stream informations
*/
#define FCC_strl			AL_ID('l', 'r', 't', 's')
/*! \def FCC_strh
 *  \brief Header of the stream
*/
#define FCC_strh			AL_ID('h', 'r', 't', 's')
/*! \def FCC_strf
 *  \brief Stream format
*/
#define FCC_strf			AL_ID('f', 'r', 't', 's')
/*! \def FCC_strd
 *  \brief Additional stream data (not used)
*/
#define FCC_strd			AL_ID('d', 'r', 't', 's')
/*! \def FCC_movi
 *  \brief List of frames in the movie
*/
#define FCC_movi			AL_ID('i', 'v', 'o', 'm')
/*! \def FCC_idx1
 *  \brief Index of the movie
*/
#define FCC_idx1			AL_ID('1', 'x', 'd', 'i')
/*! \def FCC_vids
 *  \brief Type of the stream of video
*/
#define FCC_vids			AL_ID('s', 'd', 'i', 'v')
/*! \def FCC_auds
 *  \brief Type of the stream of audio
*/
#define FCC_auds			AL_ID('s', 'd', 'u', 'a')
/*! \def FCC_JUNK
 *  \brief Just for align data
*/
#define FCC_JUNK			AL_ID('K', 'N', 'U', 'J')
/*! \def FCC_DIVX
 *  \brief FCC of DivX codec
*/
#define FCC_DIVX			AL_ID('x', 'v', 'i', 'd')
/*! \def FCC_XVID
 *  \brief FCC of XviD codec
*/
#define FCC_XVID			AL_ID('d', 'i', 'v', 'x')
/*! \def FCC_DIVX_OTHER
 *  \brief One of my DivX movies has this codec
*/
#define FCC_DIVX_OTHER	AL_ID('f', 'v', 'i', 'd')


/* types */
/*! \brief Main header of the avi file.
 *
 * Contain the basic informations for the movie
*/
typedef struct {
	int microsecpf;					/*!< \brief Microseconds per frame */
	int maxbytesps;					/*!< \brief Max bytes per second */
	int reserved1;
	int flags;							/*!< \brief Any flag for the file */
	int frames;							/*!< \brief Total of frames */
	int iniframes;						/*!< \brief Used in interleaved files */
	int streams;						/*!< \brief Number of streams, normally 2 for audio
											     and video */
	int sbufsize;						/*!< \brief Size of the suggested buffer, in bytes*/
	int width;							/*!< \brief Width of video, in pixels */
	int height;							/*!< \brief Height of video, in pixels */
	int scale;							/*!< \brief Scale, not used */
	int rate;							/*!< \brief Rate, not used */
	int start;							/*!< \brief Frame to start playing, normally 0 */
	int length;							/*!< \brief Size of data, in bytes */
} AVI_MAIN_HEADER;


/*! \brief Stream header, with information about one stream of the file
 *
 * Each stream posses one header, with it the program can know what
 * is the type of the stream, the codec used, fps in video, etc
*/
typedef struct {
	int fcctype;						/*!< \brief type of stream */
	int fcchandle;						/*!< \brief codec */
	int flags;							/*!< \brief flags of the stream */
	int reserved1;
	int iniframes;						/*!< \brief for interleaved files */
	int scale;							/*!< \brief scale */
	int rate;							/*!< \brief playback rate */
	int start;							/*!< \brief starting time of sequence */
	int length;							/*!< \brief length of sequence, in samples */
	int sbufsize;						/*!< \brief size of playback buffer */
	int quality;						/*!< \brief indicator of data quality */
	int samplesize;					/*!< \brief sample size */
} AVI_STREAM_HEADER;


/*! \brief Information about the format of one stream of the file
 *
 * Each stream posses one format, the size varies conform the \link
 * AVI_STREAM_HEADER::type type \endlink of the stream and the \link
 * AVI_STREAM_HEADER::fcchandle fcchandle \endlink of the stream.
 * \sa AVI_STREAM_HEADER::fcctype, AVI_STREAM_HEADER::fcchandle
*/
typedef struct {
	void *data;							/*!< \brief All data of stream format */
	int size;							/*!< \brief Size of the data */
} AVI_STREAM_FORMAT;


/*! \brief Information about the aditional data for stream format
 *
 * This is optional and is related to compressor/decompressor
*/
typedef struct {
	void *data;							/*!< \brief All data of stream data */
	int size;							/*!< \brief Size of the data */
} AVI_STREAM_DATA;


/*! \brief Each index entry of the file
*/
typedef struct {
	int ckid;							/*!< \brief Indentifies the data chunk */
	int flags;							/*!< \brief Flags for the data */
	int offset;							/*!< \brief Specifies the position of the chunk in the file
											 *   relative to the 'movi' list */
	int length;							/*!< \brief Length of the chunk */
} AVI_INDEX_ENTRY;


/*! \brief All the index of the movie
*/
typedef struct {
	AVI_INDEX_ENTRY *aie;			/*!< \brief Vector of index entry */
	int naie;							/*!< \brief Number of AVI_INDEX_ENTRY in vector */
	int nused;							/*!< \brief Number of used AVI_INDEX_ENTRY */
} AVI_INDEX;


/*! \brief Contain all the information necessary to handle a stream
 *
 * Each stream have one
*/
typedef struct {
	AVI_STREAM_HEADER sh;			/*!< \brief Header of the stream */
	AVI_STREAM_FORMAT sf;			/*!< \brief Format of the stream */
	AVI_STREAM_DATA sd;				/*!< \brief Other data of the stream */
	AVI_INDEX ai;						/*!< \brief All index entries related to this stream */
	void *buffer;						/*!< \brief Buffer to read a frame */
	int frame_size;					/*!< \brief Size of the last readed frame */
} AVI_STREAM;


/*! \brief AVI movie
 *
 *  This struct is the main struct to handle the avi
*/
typedef struct {
	FILE *avi;							/*!< \brief Pointer to avi file */
	AVI_MAIN_HEADER avi_mh;			/*!< \brief Main header of the avi */
	AVI_STREAM **avi_s;				/*!< \brief Stream headers/formats/aditional datas of the avi */
	int movi_offset;					/*!< \brief Start of the 'movi' list */
	int video_stream;					/*!< \brief Index of video stream */
	int audio_stream;					/*!< \brief Index of audio stream */
} AVI_MOVIE;

/*! \brief A chunk of the avi file
*/
typedef struct {
	int fcc;								/*!< \brief Fcc of the chunk */
	int subtype;						/*!< \brief When present, the "sub-type" of a chunk i.e. fcc=hdrl, sub=avih */
	int size;							/*!< \brief Size of the chunk */
	void *data;							/*!< \brief Data of the chunk, if necessary */
} AVI_CHUNK;


/* function prototypes */
AVI_MOVIE *avi_open(const char *name);
void avi_destroy(AVI_MOVIE *avi);
AVI_CHUNK *avi_chunk_read_header(AVI_MOVIE *avi);
AVI_CHUNK *avi_chunk_read(AVI_MOVIE *avi);
void avi_chunk_destroy(AVI_CHUNK *ac);
void avi_chunk_skip(AVI_MOVIE *avi);
int avi_read_frame_video(AVI_MOVIE *avi, int frame);


#ifdef __cplusplus
}
#endif

#endif // __AVI_H

/*! @} */
