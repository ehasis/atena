/*
 *      JPGalleg: JPEG image decoding routines for Allegro
 *
 *      version 1.2, by Angelo Mottola, Mar 2002.
 *
 *      Include file
 */
/*! \addtogroup jpgalleg JpgAlleg - JPG routines
 *    \brief MJpgAlleg include the JpgAlleg 1.2, by Angelo Mottola.
 *
 *    With this library, you can load a jpg image from a file or from a
 *    memory block.
 *
 *    You can download the lastest version in http://ecplusplus.com/files/jpgalleg.zip
 *    \author Angelo Mottola
 *    \date
 *    - \p Updated : 03/09/2002
 *    @{
*/

#ifndef JPGALLEG_H
#define JPGALLEG_H

#ifdef __cplusplus
extern "C" {
#endif

#include <allegro.h>

/*! \brief Decodes a JPG image from a block of memory data.
 *
 *  The \a data is the memory block, and \a pal is for compatibility, because
 *  all jpg is 24 bpp.
 *  \return Pointer to the bitmap if ok, NULL if occur error
 *  \sa load_memory_jpg()
 *  \author Angelo Mottola
 *  \date
 *  - \p Updated : 03/09/2002
*/
BITMAP *load_memory_jpg(void *data, RGB *pal);

/*! \brief Decodes a JPG image from a standard JPG file.
 *
 *  The \a filename is the file name :-), and \a pal is for compatibility,
 *  because all jpg is 24 bpp.
 *  \return Pointer to the bitmap if ok, NULL if occur error
 *  \sa load_memory_jpg()
 *  \author Angelo Mottola
 *  \date
 *  - \p Updated : 03/09/2002
*/
BITMAP *load_jpg(AL_CONST char *filename, RGB *pal);

#ifdef __cplusplus
}
#endif

#endif

/*! @} */
