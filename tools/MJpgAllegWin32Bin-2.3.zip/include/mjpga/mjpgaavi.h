#ifndef MJPGAAVI_H
#define MJPGAAVI_H

#ifdef __cplusplus
extern "C" {
#endif


/* function prototypes */
int play_movie_avi(BITMAP *bmp, int (*callback)());
int open_movie_avi(AL_CONST char *file);
void close_movie_avi(void);
int update_movie_frame_avi(void);


#ifdef __cplusplus
}
#endif

#endif
