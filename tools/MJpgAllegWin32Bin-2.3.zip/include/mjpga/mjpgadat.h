#ifndef MJPGADAT_H
#define MJPGADAT_H

#ifdef __cplusplus
extern "C" {
#endif


/* function prototypes */
int play_movie_dat(BITMAP *bmp, int (*callback)());
int open_movie_dat(AL_CONST char *file);
void close_movie_dat(void);
int update_movie_frame_dat(void);


#ifdef __cplusplus
}
#endif

#endif
