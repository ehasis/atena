#ifndef MJPGAINT_H
#define MJPGAINT_H

#ifdef __cplusplus
extern "C" {
#endif


/* function prototypes */
/* xvid decoder */
int dec_init_xvid(void);
int dec_stop_xvid(void);

/* wrapper to load jpeg */
int load_memory_jpg_ex(void *data, BITMAP *dest);
/* functions for load mpeg4 frames */
BITMAP *load_memory_dat_xvid(void *data, RGB *pal);
int load_memory_dat_xvid_ex(void *data, BITMAP *dest);
BITMAP *load_memory_avi_xvid(void *data, RGB *pal);
int load_memory_avi_xvid_ex(void *data, BITMAP *dest);

/* function to pre-calc positions and sizes for each display mode */
void mjpga_pre_calc_pos(MJPGA_MOVIE *movie, int bmpw, int bmph, int x[MJPGAM_TOTAL_MODES],
	int y[MJPGAM_TOTAL_MODES], int w[MJPGAM_TOTAL_MODES], int h[MJPGAM_TOTAL_MODES]);

/* function to say if the next number is multiply by 16 */
int mjpga_is_mul_16(int n);


#ifdef __cplusplus
}
#endif

#endif // MJPGAINT_H
