/*! \addtogroup audio Audio - functions, types and macros
 *    \brief Handle the play and poll of any audio.
 *
 *    Actually it supports only PCM uncompressed and mp3
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *  - \p Created - 07/03/2003
 *  - \p Updated - 04/04/2003
 *    @{
*/

#include <stdlib.h>
#include <string.h>
#include "mjpga.h"


static int mjpga_audio_avi_load_data(MJPGA_MOVIE *mjpga, void *data, int len);


/*! \brief Open the audio in the movie, allocating the needed memory and
 *  loading the first amount of audio.
 *
 *  The \a mjpga is a succesfully opened MJPGA_MOVIE.
 *
 *  Return 0 if ok, or 1 on error.
 *
 *  \date
 *  - 07/03/2003 - Created
 */
int mjpga_audio_open(MJPGA_MOVIE *mjpga)
{
	int i/*, j*/;
	DATAFILE *dat;
	AVI_MOVIE *avi;
//	AVI_CHUNK *ac;
	AVI_STREAM_FORMAT *audio_format = NULL;
	int len/*, pos*/;
	short int tipo;
//	short int s;
//	int pos_stream;
	short int ultimo;

	// free the memory if exists one MJPGA_AUDIO loaded
	if(mjpga->audio) {
		mjpga_audio_destroy(mjpga);
		mjpga->audio = NULL;
	}
	switch(mjpga->type) {
		case MJPGAT_DAT :
			dat = (DATAFILE *)mjpga->movie;
			for(i = 0; dat[i].type != DAT_END; i++) {
				switch(dat[i].type) {
					// case DAT_SAMPLE
					case MJPGA_AUDIO_PCM :
						mjpga->audio = malloc(sizeof(MJPGA_AUDIO));
						mjpga->audio->type = MJPGA_AUDIO_PCM;
						mjpga->audio->af.sample = (SAMPLE *)dat[i].dat;
						mjpga->audio->audio_data = NULL;
						mjpga->audio->len_data = 0;
						mjpga->audio->audio_frame = 0;
						mjpga->audio->pos_frame = 0;
						mjpga->audio->freq = ((SAMPLE *)dat[i].dat)->freq;
						mjpga->audio->bits = ((SAMPLE *)dat[i].dat)->bits;
						mjpga->audio->channels = (((SAMPLE *)dat[i].dat)->stereo) ? 2 : 1;
						return 0;
					break;
					case MJPGA_AUDIO_MP3 :
						mjpga->audio = malloc(sizeof(MJPGA_AUDIO));
						mjpga->audio->type = MJPGA_AUDIO_MP3;
						mjpga->audio->audio_data = dat[i].dat;
						mjpga->audio->len_data = dat[i].size;
						mjpga->audio->af.mp3 = almp3_create_mp3(dat[i].dat, dat[i].size);
						mjpga->audio->audio_frame = 0;
						mjpga->audio->pos_frame = 0;
						mjpga->audio->freq = almp3_get_wave_freq_mp3(mjpga->audio->af.mp3);
						mjpga->audio->bits = almp3_get_wave_bits_mp3(mjpga->audio->af.mp3);
						mjpga->audio->channels = (almp3_get_wave_is_stereo_mp3(mjpga->audio->af.mp3)) ? 2 : 1;
						return 0;
					break;
				}
			}
		break;
		case MJPGAT_AVI :
			avi = (AVI_MOVIE *)mjpga->movie;
			if(avi->audio_stream >= 0) {
				// allocating the memory
				mjpga->audio = malloc(sizeof(MJPGA_AUDIO));
				// clean the vars and store the info
				mjpga->audio->audio_data = NULL;
				mjpga->audio->len_data = 0;
				mjpga->audio->audio_frame = 0;
				mjpga->audio->pos_frame = 0;
				audio_format = &avi->avi_s[avi->audio_stream]->sf;
				memcpy((void *)&tipo, audio_format->data, 2);
				memcpy((void *)&mjpga->audio->channels, audio_format->data+2, 2);
				memcpy((void *)&mjpga->audio->freq, audio_format->data+4, 4);
				// bits is used only for PCM
				memcpy((void *)&mjpga->audio->bits, audio_format->data+14, 2);
				// choose the format
				switch(tipo) {
					case AVI_AUDIO_PCM :

						mjpga->audio->type = MJPGA_AUDIO_PCMSTREAM;
						// get the size of the buffer, 2 x suggested buffer size, or the minimum, in bytes
						len = 2 * avi->avi_s[avi->audio_stream]->sh.sbufsize;
						len = (len > 1 << 15) ? len : 1 << 15;
						mjpga->audio->len_data = len;
/*
						mjpga->audio->type = MJPGA_AUDIO_PCM;
						len = 0;
						for(i = 0; i < avi->avi_s[avi->audio_stream]->ai.nused; i++) {
							// read data header from avi
							if(fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[i].offset, SEEK_SET)) {
								free(mjpga->audio);
								return 1;
							}
							ac = avi_chunk_read_header(avi);
							// update the size
							len += ac->size;
							// destroy the memory used for the chunk
							avi_chunk_destroy(ac);
						}
						// calc the size of the sample, in sample units
						len /= mjpga->audio->channels;
						if(mjpga->audio->bits == 16)
							len /= 2;
						mjpga->audio->af.sample = create_sample(mjpga->audio->bits,
							((mjpga->audio->channels == 2) ? TRUE : FALSE), mjpga->audio->freq, len);
						// fill the sample with data
						pos = 0;
						for(i = 0; i < avi->avi_s[avi->audio_stream]->ai.nused; i++) {
							// read data from avi
							fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[i].offset, SEEK_SET);
							ac = avi_chunk_read_header(avi);
							// choose the appropriate method to load data
							if(mjpga->audio->bits == 8) {
								fread( (mjpga->audio->af.sample)->data+pos, ac->size, 1, avi->avi);
							}
							else {
								for(j=0; j < ac->size/2; j++) {
									fread((void *)&s, 2, 1, avi->avi);
									((signed short*)((mjpga->audio->af.sample)->data+pos))[j] = s ^ 0x8000;
								}
							}
							// update sample position
							pos += ac->size;
							avi_chunk_destroy(ac);
						}
*/
					break;
					case AVI_AUDIO_MP3 :
						mjpga->audio->type = MJPGA_AUDIO_MP3STREAM;
						// get the size of the buffer, 2 x suggested buffer size, or the minimum, in bytes
						len = 2 * avi->avi_s[avi->audio_stream]->sh.sbufsize;
						len = (len > 1 << 15) ? len : 1 << 15;
						mjpga->audio->len_data = len;
						mjpga->audio->audio_data = malloc(len);

						mjpga_audio_avi_load_data(mjpga, mjpga->audio->audio_data, len);
						if(mjpga->audio->audio_frame == avi->avi_s[avi->audio_stream]->ai.nused) {
							ultimo = TRUE;
						}
						else {
							ultimo = FALSE;
						}
						mjpga->audio->af.mp3stream = almp3_create_mp3stream(mjpga->audio->audio_data, len, ultimo);
					break;
					default :
						free(mjpga->audio);
						mjpga->audio = NULL;
					break;
				}
			}
		break;
	}
	return 1;
}


/*! \brief Poll the audio.
 *
 *  The \a mjpga is a succesfully opened MJPGA_MOVIE.
 *
 *  Return the result of the poll.
 *
 *  \date
 *  - \p Created - 07/03/2003
 *  - \p Updated - 04/04/2003
 */
int mjpga_audio_poll(MJPGA_MOVIE *mjpga)
{
	AVI_MOVIE *avi;
	void *stream;
	int i, len;

	if(!mjpga->audio) {
		return 0;
	}
	switch(mjpga->type) {
		case MJPGAT_DAT :
			switch(mjpga->audio->type) {
				case MJPGA_AUDIO_MP3 :
					return almp3_poll_mp3(mjpga->audio->af.mp3);
				break;
			}
		break;
		case MJPGAT_AVI :
			avi = (AVI_MOVIE *)mjpga->movie;
			switch(mjpga->audio->type) {
				case MJPGA_AUDIO_PCM :
					;
				break;
				case MJPGA_AUDIO_PCMSTREAM :
					// if it's in the last frame, return
					if(mjpga->audio->audio_frame == avi->avi_s[avi->audio_stream]->ai.nused) {
						// audio is over
						return 1;
					}
					// verify if need to load more data
					stream = get_audio_stream_buffer(mjpga->audio->af.audiostream);
					if(stream) {
						len = mjpga_audio_avi_load_data(mjpga, stream, mjpga->audio->len_data);
						if(mjpga->audio->bits == 16) {
							// convert to unsigned format
							for(i = 0; i < len >> 1; i++) {
								*(((unsigned short *)stream) + i) ^= 0x8000;
							}
						}
						free_audio_stream_buffer(mjpga->audio->af.audiostream);
					}
				break;
				case MJPGA_AUDIO_MP3STREAM :
					stream = almp3_get_mp3stream_buffer(mjpga->audio->af.mp3stream);
					if(stream) {
						len = mjpga_audio_avi_load_data(mjpga, stream, mjpga->audio->len_data);
						if(mjpga->audio->audio_frame == avi->avi_s[avi->audio_stream]->ai.nused) {
							almp3_free_mp3stream_buffer(mjpga->audio->af.mp3stream, len);
						}
						else {
							almp3_free_mp3stream_buffer(mjpga->audio->af.mp3stream, -1);
						}
					}
					return almp3_poll_mp3stream(mjpga->audio->af.mp3stream);
				break;
			}
		break;
	}
	return 0;
}


/*! \brief Free the memory.
 *
 *  The \a mjpga is a succesfully opened MJPGA_MOVIE.
 *
 *  \date
 *  - \p Created - 07/03/2003
 *  - \p Updated - 04/04/2003
 */
void mjpga_audio_destroy(MJPGA_MOVIE *mjpga)
{
	if(mjpga->audio) {
		switch(mjpga->type) {
			case MJPGAT_DAT :
				switch(mjpga->audio->type) {
					case MJPGA_AUDIO_MP3 :
						almp3_destroy_mp3(mjpga->audio->af.mp3);
					break;
				}
			break;
			case MJPGAT_AVI :
				switch(mjpga->audio->type) {
					case MJPGA_AUDIO_PCMSTREAM :
						stop_audio_stream(mjpga->audio->af.audiostream);
					break;
					case MJPGA_AUDIO_MP3STREAM :
						almp3_destroy_mp3stream(mjpga->audio->af.mp3stream);
						free(mjpga->audio->audio_data);
					default :
						;
					break;
				}
			break;
			default :
				;
			break;
		}
		free(mjpga->audio);
		mjpga->audio = NULL;
	}
}


/*! \brief Play the movie's audio
 *
 * The argument \a mjpga is the movie previously opened
 *
 *  \date
 *  - \p Created - 07/03/2003
 *  - \p Updated - 04/04/2003
 */
void mjpga_audio_play(MJPGA_MOVIE *mjpga)
{
	int samples;
	void *stream;
	int i, len;

	if(!mjpga->audio) {
		return;
	}
	switch(mjpga->audio->type) {
		case MJPGA_AUDIO_PCM :
			play_sample(mjpga->audio->af.sample, 255, 128, 1000, 0);
		break;
		case MJPGA_AUDIO_PCMSTREAM :
			samples = mjpga->audio->len_data;
			samples /= mjpga->audio->channels;
			if(mjpga->audio->bits == 16)
				samples /= 2;
			mjpga->audio->af.audiostream = play_audio_stream(samples, mjpga->audio->bits,
				(mjpga->audio->channels == 2), mjpga->audio->freq, 255, 128);
			stream = get_audio_stream_buffer(mjpga->audio->af.audiostream);
			if(stream) {
				len = mjpga_audio_avi_load_data(mjpga, stream, mjpga->audio->len_data);
				if(mjpga->audio->bits == 16) {
					// convert to unsigned format
					for(i = 0; i < len >> 1; i++) {
						*(((unsigned short *)stream) + i) ^= 0x8000;
					}
				}
				free_audio_stream_buffer(mjpga->audio->af.audiostream);
			}
		break;
		case MJPGA_AUDIO_MP3 :
			almp3_play_mp3(mjpga->audio->af.mp3, 1 << 15, 255, 128);;
		break;
		case MJPGA_AUDIO_MP3STREAM :
			almp3_play_mp3stream(mjpga->audio->af.mp3stream, mjpga->audio->len_data, 255, 128);
		break;
	}
}


/*! \brief Load data from avi files
 *
 *  Parameter \a data is the pointer to store a maximum of \a len bytes. If the
 *  buffer, at the end of function, isn't filled, fill with 0's.
 *
 *  \return The amount of bytes really readed from the avi
 *  - \p Created - 04/04/2003
 *  - \p Updated - 04/04/2003
 */
static int mjpga_audio_avi_load_data(MJPGA_MOVIE *mjpga, void *data, int len)
{
	int pos_stream;
	short int ultimo;
	AVI_MOVIE *avi;
	AVI_CHUNK *ac;

	avi = (AVI_MOVIE *)mjpga->movie;
	// if it's in the last frame, return
	if(mjpga->audio->audio_frame == avi->avi_s[avi->audio_stream]->ai.nused) {
		// audio is over
		return 1;
	}

	pos_stream = 0;
	ultimo = FALSE;
	while(pos_stream < len && ultimo != TRUE) {
		// posiciona no local correto do avi
		fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[mjpga->audio->audio_frame].offset, SEEK_SET);
		// verifica se todo o frame cabe no buffer
		ac = avi_chunk_read_header(avi);
		if(ac->size - mjpga->audio->pos_frame <= len - pos_stream) {
			// se cabe, copia tudo
			// posiciona no local correto
			fseek(avi->avi, mjpga->audio->pos_frame, SEEK_CUR);
			// l� no buffer
			fread(data + pos_stream, ac->size - mjpga->audio->pos_frame,
				1, avi->avi);
			// atualiza posi��es
			pos_stream += ac->size - mjpga->audio->pos_frame;
			mjpga->audio->pos_frame = 0;
			// incrementa o frame
			mjpga->audio->audio_frame++;
		}
		else {
			// se n�o cabe, copia o que d�
			// posiciona no local correto
			fseek(avi->avi, mjpga->audio->pos_frame, SEEK_CUR);
			// l� no buffer
			fread(data + pos_stream, len - pos_stream, 1, avi->avi);
			// atualiza posi��es
			mjpga->audio->pos_frame = len - pos_stream;
			pos_stream = len;
		}
		avi_chunk_destroy(ac);
		// verifica se � o �ltimo frame
		if(mjpga->audio->audio_frame == avi->avi_s[avi->audio_stream]->ai.nused) {
			ultimo = TRUE;
		}
	}
	if(pos_stream != len) {
		memset( (void *) (((unsigned char *)data)+pos_stream), 0, len - pos_stream);
	}
	return pos_stream;
}



/*! @} */
