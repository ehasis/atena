/*! \addtogroup avi AVI - functions, types and macros
 *    \brief Handle the load of avi file.
 *
 *    You can use this module separately of MJpgAlleg, to implement your own
 *    AVI library.
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *    - 19/09/2002 - Start
 *    - 11/10/2002 - Start converting comments to doxygen style
 *    - 03/11/2002 - Bug fixes for version 2.11 (new line at end of file)
 *    - 02/04/2003 - Searching for a possible bug...
 *    - 03/04/2003 - It's not really a bug, but an error in understanding the
 *                   specs of avi. The length, in the stream header, is the
 *                   numer of samples, not frames.
 *    @{
*/

//#define DEBUGMODE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <allegro.h>
#include "mjpga/avi.h"

static int avi_read_headers(AVI_MOVIE *avi);
static int avi_read_main_header(AVI_MOVIE *avi);
static int avi_read_stream_list(AVI_MOVIE *avi);
static int avi_read_movi_offset(AVI_MOVIE *avi);
static int avi_read_index(AVI_MOVIE *avi);


/*! \brief Opens the file \a name and verifies if it is a valid avi.
 *
 *  This function will see if it's a valid \link FCC_RIFF RIFF \endlink
 *  file, of type \link FCC_AVI AVI \endlink, and will load the \link
 *  AVI_MAIN_HEADER header \endlink of the avi, the \link AVI_STREAM
 *  stream info \endlink, the offset of \link AVI_MOVIE::movi_offset movi list
 *  \endlink and the \link AVI_INDEX index \endlink of the file
 *  \return pointer to a AVI_MOVIE struct if ok, NULL on error
 *  \sa avi_destroy(), avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : 23/09/2002
 */
AVI_MOVIE *avi_open(const char *name)
{
	AVI_MOVIE *avi;
	AVI_CHUNK *ac;

	avi = malloc(sizeof(AVI_MOVIE));
	// no memory?
	if(!avi)
		return NULL;
	avi->avi = fopen(name, "rb");
	// can't open file?
	if(!avi->avi) {
		free(avi);
		return NULL;
	}
	// is a valid avi file?
	ac = avi_chunk_read_header(avi);
	if(ac->fcc != FCC_RIFF || ac->subtype != FCC_AVI) {
		// no!
		fclose(avi->avi);
		free(avi);
		avi_chunk_destroy(ac);
		return NULL;
	}
	avi_chunk_destroy(ac);
	// the file is valid, then read the list of headers
	TRACE("Lendo cabe�alhos...\n");
	if(avi_read_headers(avi)) {
		avi_destroy(avi);
		return NULL;
	}
	// now read the position of the beginning of list 'movi'
	if(avi_read_movi_offset(avi)) {
		avi_destroy(avi);
		return NULL;
	}
	// now read the index entries
	if(avi_read_index(avi)) {
		avi_destroy(avi);
		return NULL;
	}
	// return the pointer to the AVI_MOVIE
	return avi;
}


/*! \brief Frees the memory allocated and close the file
 *
 *  The \a avi is a valid AVI_MOVIE pointer
 *  \return Nothing
 *  \sa avi_open()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : 22/10/2002
 */
void avi_destroy(AVI_MOVIE *avi)
{
	int i;
	if(!avi)
		return;
	if(avi->avi != NULL)
		fclose(avi->avi);
	if(avi->avi_s != NULL) {
		for(i=0; i<avi->avi_mh.streams; i++) {
			if(avi->avi_s[i]->sf.data != NULL)
				free(avi->avi_s[i]->sf.data);
			if(avi->avi_s[i]->sd.data != NULL)
				free(avi->avi_s[i]->sd.data);
			if(avi->avi_s[i]->ai.aie != NULL)
				free(avi->avi_s[i]->ai.aie);
			if(avi->avi_s[i]->buffer != NULL)
				free(avi->avi_s[i]->buffer);
		}
		free(avi->avi_s);
	}
	free(avi);
}


/*! \brief Reads the fcc, size and sub-type of the next \link AVI_CHUNK chunk
 * \endlink in the file.
 *
 *  The subtype is read for RIFF and LIST fcc.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return Pointer to AVI_CHUNK struct if ok, NULL on error
 *  \sa avi_chunk_read(), avi_chunk_destroy(), avi_chunk_skip()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : -
 */
AVI_CHUNK *avi_chunk_read_header(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	ac = malloc(sizeof(AVI_CHUNK));
	if(!ac)
		return NULL;
	ac->data = NULL;
	fread(&ac->fcc, 4, 1, avi->avi);
	fread(&ac->size, 4, 1, avi->avi);
	// read sub-type for some fcc's
	switch(ac->fcc) {
		case FCC_RIFF :
		case FCC_LIST :
			fread(&ac->subtype, 4, 1, avi->avi);
		break;
		default :
			ac->subtype = 0;
		break;
	}
	return ac;
}


/*! \brief Reads the fcc, size, sub-type and data of the next \link AVI_CHUNK
 *  chunk \endlink in the file.
 *
 *  The subtype is read for RIFF and LIST fcc.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return Pointer to AVI_CHUNK struct if ok, NULL on error
 *  \sa avi_chunk_read_header(), avi_chunk_destroy(), avi_chunk_skip()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : -
 */
AVI_CHUNK *avi_chunk_read(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	ac = avi_chunk_read_header(avi);
	ac->data = malloc(ac->size);
	if(!ac->data) {
		avi_chunk_destroy(ac);
		return NULL;
	}
	fread(ac->data, ac->size, 1, avi->avi);
	if(feof(avi->avi)) {
		avi_chunk_destroy(ac);
		return NULL;
	}
	return ac;
}


/*! \brief Frees the memory allocated to a \link AVI_CHUNK chunk \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return Nothing
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : -
 */
void avi_chunk_destroy(AVI_CHUNK *ac)
{
	if(ac->data)
		free(ac->data);
	free(ac);
}


/*! \brief Skip the next \link AVI_CHUNK chunk \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return Nothing
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : -
 */
void avi_chunk_skip(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	ac = avi_chunk_read_header(avi);
	fseek(avi->avi, ac->size, SEEK_CUR);
}


/*! \brief Read all the \link AVI_STREAM_HEADER stream headers \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : 22/10/2002
 */
static int avi_read_headers(AVI_MOVIE *avi)
{
	int er, i;
	AVI_CHUNK *ac;
	ac = avi_chunk_read_header(avi);
	// first, verify if is the headers list
	if(ac->fcc != FCC_LIST || ac->subtype != FCC_hdrl) {
		avi_chunk_destroy(ac);
		return 1;
	}
	avi_chunk_destroy(ac);
	// yes, it is, so read the avi main header
	er = avi_read_main_header(avi);
	if(er)
		return er;
	// allocate memory for streams headers/format/data
	avi->avi_s = malloc(avi->avi_mh.streams*sizeof(AVI_STREAM *));
	if(avi->avi_s == NULL) {
		// no memory?
		return 1;
	}

	if(avi->avi_mh.streams < 1) {
		return 1;
	}

	// set initial values to audio/video stream index
	avi->audio_stream = -1;
	avi->video_stream = -1;

	// alloc the memory and initialize for all streams
	for(i=0; i<avi->avi_mh.streams; i++) {
		avi->avi_s[i] = malloc(sizeof(AVI_STREAM));
		if(avi->avi_s[i] == NULL) {
			// no memory?
			return 1;
		}
		avi->avi_s[i]->sf.data = NULL;
		avi->avi_s[i]->sf.size = 0;
		avi->avi_s[i]->sd.data = NULL;
		avi->avi_s[i]->sd.size = 0;
		avi->avi_s[i]->buffer = NULL;
		avi->avi_s[i]->frame_size = -1;
		avi->avi_s[i]->ai.aie = NULL;
		avi->avi_s[i]->ai.naie = -1;
		avi->avi_s[i]->ai.nused = -1;
	}

	// read the stream list
	er = avi_read_stream_list(avi);
	if(er) {
		// error
		return er;
	}
	return 0;
}


/*! \brief Read the \link AVI_MAIN_HEADER main header \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : -
 */
static int avi_read_main_header(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	ac = avi_chunk_read_header(avi);
	// is the avi main header
	if(ac->fcc != FCC_avih) {
		// no!
		avi_chunk_destroy(ac);
		return 1;
	}
	fread(&avi->avi_mh, ac->size, 1, avi->avi);
	avi_chunk_destroy(ac);
	return 0;
}


/*! \brief Read all the \link AVI_STREAM streams \endlink and alloc the
 *  \link AVI_STREAM::buffer buffer \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 19/09/2002
 *  - \p Updated : 03/04/2003
 */
static int avi_read_stream_list(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	int list;
	int i;
	for(i=0; i<avi->avi_mh.streams; i++) {
		ac = avi_chunk_read_header(avi);
		// is the list of streams
		if(ac->fcc != FCC_LIST || ac->subtype != FCC_strl) {
			// no!
			avi_chunk_destroy(ac);
			return 1;
		}
		avi_chunk_destroy(ac);

		// read the header
		ac = avi_chunk_read_header(avi);
		if(ac->fcc != FCC_strh) {
			avi_chunk_destroy(ac);
			return 1;
		}
		fread(&avi->avi_s[i]->sh, ac->size, 1, avi->avi);
		avi_chunk_destroy(ac);

		// if the stream is the video stream, set the 'video_stream' to i
		if(avi->avi_s[i]->sh.fcctype == FCC_vids) {
			avi->video_stream = i;
		}
		// else if is the audio stream, set 'audio_stream'
		else if(avi->avi_s[i]->sh.fcctype == FCC_auds) {
			avi->audio_stream = i;
		}

		// alloc the buffer
		avi->avi_s[i]->buffer = malloc(avi->avi_s[i]->sh.sbufsize);
		avi->avi_s[i]->frame_size = -1;

		// read the format
		ac = avi_chunk_read_header(avi);
		if(ac->fcc != FCC_strf) {
			avi_chunk_destroy(ac);
			return 1;
		}
		avi->avi_s[i]->sf.data = malloc(ac->size);
		fread(avi->avi_s[i]->sf.data, ac->size, 1, avi->avi);
		avi->avi_s[i]->sf.size = ac->size;
		avi_chunk_destroy(ac);

		// because other chunks are optional, go reading for the next FCC_LIST chunk
		do {
			// read next chunk
			ac = avi_chunk_read_header(avi);
			list = 0;
			switch(ac->fcc) {
				case FCC_strd :
					avi->avi_s[i]->sd.data = malloc(ac->size);
					fread(avi->avi_s[i]->sd.data, ac->size, 1, avi->avi);
					avi->avi_s[i]->sd.size = ac->size;
				break;
				// is the next stream or the 'movi' list
				case FCC_LIST :
					// go back 12 bytes
					fseek(avi->avi, -12, SEEK_CUR);
					list = 1;
				break;
				case FCC_JUNK :
				default :
					fseek(avi->avi, ac->size, SEEK_CUR);
				break;
			}
			avi_chunk_destroy(ac);
		} while(!list);
	}
	return 0;
}


/*! \brief Search to the list \link AVI_MOVIE::movi_offset movi \endlink and
 *  store the position in the file.
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 23/09/2002
 *  - \p Updated : -
 */
static int avi_read_movi_offset(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac;
	int ok=1;
	do {
		ac = avi_chunk_read_header(avi);
		if(feof(avi->avi)) {
			avi_chunk_destroy(ac);
			return 1;
		}
		if(ac->fcc == FCC_LIST) {
			if(ac->subtype == FCC_movi) {
				avi->movi_offset = ftell(avi->avi)-4;
				ok = 0;
			}
			fseek(avi->avi, ac->size-4, SEEK_CUR);
		}
		else {
			fseek(avi->avi, ac->size, SEEK_CUR);
		}
		avi_chunk_destroy(ac);
	} while(ok);
	return 0;
}


/*! \brief Reads all the entries in the \link FCC_idx1 idx1 \endlink chunk and
 *  place it in the related \link AVI_STREAM::ai stream index \endlink
 *
 *  The \a avi is a valid AVI_MOVIE pointer.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 23/09/2002
 *  - \p Updated : 03/04/2003
 */
static int avi_read_index(AVI_MOVIE *avi)
{
	AVI_CHUNK *ac = NULL;
	AVI_INDEX_ENTRY *temp = NULL;
	int i, stream, *pos, nindex;
	int done;
	int *count;

	// alloc and clear the space for the counts variable
	count = (int *) malloc(sizeof(int) * avi->avi_mh.streams);
	if(!count) {
		// no memory
		return 1;
	}
	memset((void *)count, 0, sizeof(int) * avi->avi_mh.streams);

	// first, count the number of indexes of each stream and load in a temporary
	// place in memory
	nindex = 0;
	done = 0;
	do {
		ac = avi_chunk_read_header(avi);
		if(feof(avi->avi)) {
			free(count);
			avi_chunk_destroy(ac);
			return 1;
		}
		if(ac->fcc == FCC_LIST) {
			fseek(avi->avi, ac->size-4, SEEK_CUR);
		}
		else {
			if(ac->fcc == FCC_idx1) {
				// found the idx1 chunk
				// calc the number of indexes
				nindex = ac->size/sizeof(AVI_INDEX_ENTRY);
				// alloc memory to temporary buffer
				temp = (AVI_INDEX_ENTRY *)malloc(ac->size);
				if(!temp) {
					// no memory for buffer
					free(count);
					avi_chunk_destroy(ac);
					return 1;
				}
				// read all the idx1
				fread((void *)temp, ac->size, 1, avi->avi);
				if(feof(avi->avi)) {
					// unexpected eof
					free(count);
					free(temp);
					avi_chunk_destroy(ac);
					return 1;
				}
				// count the number of indexes of each stream
				for(i=0; i<nindex; i++) {
					stream = ((temp[i].ckid & 0xFF00) >> 8) - '0';
					if(stream < 0 || stream >= avi->avi_mh.streams) {
						// invalid stream number
						free(count);
						free(temp);
						avi_chunk_destroy(ac);
						return 1;
					}
					count[stream]++;
				}
				done = 1;
			}
			else
				fseek(avi->avi, ac->size, SEEK_CUR);
		}
		avi_chunk_destroy(ac);
	} while(!done);

	// then, alloc the memory in each AVI_INDEX and load the indexes
	for(i = 0; i < avi->avi_mh.streams; i++) {
		// alloc the memory
		avi->avi_s[i]->ai.aie = (AVI_INDEX_ENTRY *)malloc(sizeof(AVI_INDEX_ENTRY) * count[i]);
		if(!avi->avi_s[i]->ai.aie) {
			// no memory
			free(count);
			free(temp);
			for(i = i-1; i >= 0; i--) {
				free(avi->avi_s[i]->ai.aie);
			}
			return 1;
		}
		// set the number of indexes
		avi->avi_s[i]->ai.naie = count[i];
		// number of used entries
		avi->avi_s[i]->ai.nused = 0;
	}
	// copy from temp buffer to AVI_INDEX of each stream
	for(i = 0; i < nindex; i++) {
		stream = ((temp[i].ckid & 0xFF00) >> 8) - '0';
		pos = &avi->avi_s[stream]->ai.nused;
		avi->avi_s[stream]->ai.aie[*pos] = temp[i];
		(*pos)++;
	}
	// free the buffers
	free(count);
	free(temp);

	return 0;
}


/*! \brief Read a frame of video.
 *
 *  Stores the data in the \link AVI_STREAM::buffer buffer \endlink of video
 *  stream and the size of frame in \link AVI_STREAM::frame_size frame_size
 *  \endlink.
 *
 *  The \a avi is a valid AVI_MOVIE pointer, and \a frame is the number of the
 *  frame to read.
 *  \return 0 is ok, non zero is error
 *  \sa avi_chunk_read_header(), avi_chunk_read()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 23/09/2002
 *  - \p Updated : 22/10/2002
 */
int avi_read_frame_video(AVI_MOVIE *avi, int frame)
{
	AVI_CHUNK *ac;
	int fpos;

	if( (frame < 0) || (avi->video_stream < 0) )
		return 1;
	if(avi->avi_s[avi->video_stream]->ai.nused < frame)
		return 1;
	fpos = avi->movi_offset + avi->avi_s[avi->video_stream]->ai.aie[frame].offset;
	fseek(avi->avi, fpos, SEEK_SET);
	ac = avi_chunk_read_header(avi);
	if(!ac)
		return 1;
	fread(avi->avi_s[avi->video_stream]->buffer, ac->size, 1, avi->avi);
	if(feof(avi->avi)) {
		avi_chunk_destroy(ac);
		return 1;
	}
	avi->avi_s[avi->video_stream]->frame_size = ac->size;
	avi_chunk_destroy(ac);
	return 0;
}

/*! @} */
