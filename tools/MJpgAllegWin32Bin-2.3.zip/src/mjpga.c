/*! \addtogroup mjpga
 *    \brief The soul of MJpgAlleg is here.
 *
 *    This files is the core of the library.
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *    - ??/05/2002 - Start version 1.0
 *    - 29/09/2002 - Start of version 2.0
 *    - 09/10/2002 - Start converting comments to doxygen style
 *    - 21/10/2002 - Timer function moved to top
 *    - 03/11/2002 - Bug fixes for version 2.11 (new line at end of file)
 *    @{
*/

#include <allegro.h>
#include <string.h>
#include "mjpga.h"

/* global vars */
/*! \hideinitializer \brief Current movie playing. */
MJPGA_MOVIE *the_movie = NULL;
/*! \hideinitializer \brief When timer_movie > 0, is necessary to update the frame. */
volatile int timer_movie;


/* static prototypes */
/* Increments the timer */
static void timer_movie_func(void);
/* Convert a string to a int form */
static int clean_typename(AL_CONST char *type);


/*!
 *  \brief Static function to update the timer variable.
 *  \return Nothing
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : ??/05/2002
 *  - \p Updated : -
 */
static void timer_movie_func(void)
{
	timer_movie++;
}
END_OF_FUNCTION(timer_movie_func);


/*! \brief Alloc the memory for the movie.
 *
 *  Alloc and start the global var the_movie and lock the timer and timer
 *  function in the first call.
 *  \return Nothing
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : ??/05/2002
 *  - \p Updated : 09/10/2002
 */
void init_movie(void)
{
	static int ok = 0;
	if(the_movie)
		close_movie();
	the_movie = malloc(sizeof(MJPGA_MOVIE));
	the_movie->type = 0;
	the_movie->subtype = 0;
	the_movie->movie = NULL;
	the_movie->audio = NULL;
	the_movie->frame = -1;
	the_movie->size = 0;
	the_movie->last_frame = -1;
	the_movie->xvid = the_movie->yvid = -1;
	strcpy(the_movie->desc, empty_string);
	the_movie->fps = -1;
	the_movie->mode = 0;
	if(!ok) {
		LOCK_VARIABLE(timer_movie);
		LOCK_FUNCTION(timer_movie_func);
		ok = 1;
	}
}


/*! \brief Play the movie, like play_fli().
 *
 *  This function is like play_fli(). It will open the \a file calling
 *  open_movie(), and if it's ok, call the appropriate play_movie_xxx() based
 *  on the type of the movie.
 *
 *  The \a bmp is the destination bitmap, and \a callback, if not NULL, will
 *  be called every time during the execution of the movie.
 *
 *  If callback returns non zero, the movie stops.
 *  \return 1 on error, 0 ok
 *  \sa play_movie_dat(), play_movie_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : ??/05/2002
 *  - \p Updated : 30/9/2002
 */
int play_movie(const char *file, BITMAP *bmp, int (*callback)())
{
	int (*play)(BITMAP *bmp, int (*callback)());
	if(open_movie(file)) {
		return 1;
	}
	switch(the_movie->type) {
		case MJPGAT_DAT :
			play = play_movie_dat;
		break;
		case MJPGAT_AVI :
			play = play_movie_avi;
		break;
		default :
			return 1;
		break;
	}
	return play(bmp, callback);;
}


/*! \brief Open a movie and prepare to play.
 *
 *  It will open \a file with the appropriate function, based on the extension
 *  of \a file.
 *  \return 1 on error, 0 ok
 *  \sa open_movie_dat(), open_movie_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : ??/05/2002
 *  - \p Updated : 30/09/2002
 */
int open_movie(const char *file)
{
	int t;

	t = clean_typename(get_extension(file));
	switch(t) {
		case MJPGAT_DAT :
			open_movie_dat(file);
		break;
		case MJPGAT_AVI :
			open_movie_avi(file);
		break;
		default :
			return 1;
		break;
	}
	if(the_movie == NULL) {
		return 1;
	}

	install_int_ex(timer_movie_func, (long)(TIMERS_PER_SECOND/the_movie->fps));
	timer_movie=0;
	return 0;
}


/*! \brief Close the movie.
 *
 *  This function call the appropriate close_movie_xxx() for each type
 *  of movie, and free the memory.
 *  \return Nothing
 *  \sa close_movie_dat(), close_movie_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : ??/05/2002
 *  - \p Updated : 30/9/2002
 */
void close_movie(void)
{
	if(the_movie != NULL) {
		switch(the_movie->type) {
			case MJPGAT_DAT :
				close_movie_dat();
			break;
			case MJPGAT_AVI :
				close_movie_avi();
			break;
			default :
			break;
		}
	}
	the_movie = NULL;
	remove_int(timer_movie_func);
}


/*! \brief Jump to current frame.
 *
 *  Call this for change to actual movie frame.
 *  \return 0 if ok, non zero if end of movie
 *  \sa update_movie_frame_dat(), update_movie_frame_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/9/2002
 *  - \p Updated : -
 */
int update_movie_frame(void)
{
	switch(the_movie->type) {
		case MJPGAT_DAT :
			return update_movie_frame_dat();
		break;
		case MJPGAT_AVI :
			return update_movie_frame_avi();
		default :
			return 2;
		break;
	}
}


/*! \brief Set movie mode.
 *
 *  Set the display mode (0 is normal, non zero is fullscreen).
 *
 *  Maybe I can add more modes in the near future (50%, 200%, ...).
 *  \return Nothing
 *  \sa get_mode_movie()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/9/2002
 *  - \p Updated : -
 */
void set_mode_movie(unsigned char mode)
{
	the_movie->mode = mode;
}


/*! \brief Get movie mode.
 *
 *  Return the display mode (0 is normal, non zero is fullscreen).
 *  \return Current display mode
 *  \sa set_mode_movie()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/9/2002
 *  - \p Updated : -
*/
unsigned char get_mode_movie(void)
{
	return the_movie->mode;
}


/*! \brief Static function to clean up an object type string, and packs it in
 *  an integer.
 *
 *  Uses up to 4 bytes of the string
 *  \return The packed string
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/9/2002
 *  - \p Updated : -
 */
static int clean_typename(AL_CONST char *type)
{
	int c1, c2, c3, c4;

	if (!type)
		return 0;

	c1 = (*type) ? utoupper(*(type++)) : ' ';
	c2 = (*type) ? utoupper(*(type++)) : ' ';
	c3 = (*type) ? utoupper(*(type++)) : ' ';
	c4 = (*type) ? utoupper(*(type++)) : ' ';

	return DAT_ID(c1, c2, c3, c4);
}

/*! @} */
