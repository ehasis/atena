/*! \addtogroup mjpgaavi MJpgAlleg - AVI movie
 *    \brief This file is to help load and play .avi files.
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *    - 01/10/2002 - Start
 *    - 10/10/2002 - Start conversion of comments for doxygen
 *    - 21/10/2002 - Start adding support for audio (PCM uncompressed) to
 *      avi files
 *    - 22/10/2002 - Updating code to use version 2.1
 *    - 03/11/2002 - Bug fixes for version 2.11 (included string.h and new
 *      line at end of file)
 *    - 08/03/2003 - Updating some functions to use the new way to play sounds.
 *    - 02/04/2003 - Optimized play_movie_avi() to use hardware acceleration.
 *    @{
 */

//#define DEBUGMODE

#include <string.h>
#include <xvid.h>
#include "mjpga.h"
#include "mjpga/mjpgaint.h"


/*! \brief Play a movie from an avi file.
 *
 *  This function is like play_fli(). The movie has been previously opened
 *  with open_movie(), and this function is called if the movie is in an
 *  avi file.
 *
 *  The \a bmp is the destination bitmap, and \a callback, if not NULL, will be
 *  called every time during the execution of the movie.
 *
 *  If callback returns non zero, the movie stops.
 *  \return 1 on error, 0 ok
 *  \sa play_movie(), play_movie_dat()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 01/10/2002
 *  - \p Updated : 04/04/2003
 */
int play_movie_avi(BITMAP *bmp, int (*callback)())
{
	BITMAP *vid[2], *temp;
	AVI_MOVIE *avi;
	int r;
	// used in screen modes
	int x[MJPGAM_TOTAL_MODES], y[MJPGAM_TOTAL_MODES], w[MJPGAM_TOTAL_MODES], h[MJPGAM_TOTAL_MODES];

	// pre-calc to different modes of display
	mjpga_pre_calc_pos(the_movie, bmp->w, bmp->h, x, y, w, h);

	// creating the bitmap, try to use the possible acceleration
	temp = NULL;
	if( (gfx_capabilities & GFX_HW_VRAM_BLIT) && (bmp == screen) && mjpga_is_mul_16(the_movie->xvid) ) {
		// create video bitmaps, if possible
		// note: if the 'bmp' is the screen bitmap, it's needed to be
		// created again, to give the correct output
		temp = screen;
		bmp = create_video_bitmap(SCREEN_W, SCREEN_H);
		if(!bmp) {
			// if not enough video memory, restore the bmp pointer
			temp = NULL;
			bmp = screen;
			// and try system bitmap
			vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid[0]) {
				return 1;
			}
			// because only blits are accelerated, stretch_blit will need a
			// system bitmap
			vid[1] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid[1]) {
				destroy_bitmap(vid[0]);
				return 1;
			}
		}
		else {
			// if enough video memory, try video memory for the bitmap
			// where the decoded frame will be
			vid[0] = create_video_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid) {
				// if not enough video memory, restore the bmp pointer
				destroy_bitmap(bmp);
				bmp = temp;
				temp = NULL;
				// and try system bitmap
				vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
				if(!vid[0]) {
					return 1;
				}
				vid[1] = vid[0];
			}
			else {
				// because only blits are accelerated, stretch_blit will need a
				// system bitmap
				vid[1] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
				if(!vid[1]) {
					destroy_bitmap(bmp);
					bmp = temp;
					temp = NULL;
					destroy_bitmap(vid[0]);
					return 1;
				}
				show_video_bitmap(bmp);
			}
		}
	}
	else {
		// bmp isn't the screen (unusual)
		vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
		if(!vid[0]) {
			return 1;
		}
		vid[1] = vid[0];
	}

	// start the decoder
	dec_init_xvid();

	// load the first frame
	avi = (AVI_MOVIE *)the_movie->movie;
	avi_read_frame_video(avi, the_movie->frame);
	if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
		// normal and center mode use blit (can be vram -> vram accelerated)
		r = load_memory_avi_xvid_ex(avi->avi_s[avi->video_stream]->buffer, vid[0]);
	}
	else {
		// others, use stretch_blit
		r = load_memory_avi_xvid_ex(avi->avi_s[avi->video_stream]->buffer, vid[1]);
	}
	if(r) {
		// error
		destroy_bitmap(vid[0]);
		if(vid[1] != vid[0]) {
			destroy_bitmap(vid[1]);
		}
		if(temp) {
			destroy_bitmap(bmp);
			bmp = temp;
			show_video_bitmap(bmp);
		}
		close_movie();
		return 1;
	}
	if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
		// normal and center mode use blit (can be vram -> vram accelerated)
		blit(vid[0], bmp, 0, 0, x[the_movie->mode], y[the_movie->mode], the_movie->xvid, the_movie->yvid);
	}
	else {
		// others, use stretch_blit
		stretch_blit(vid[1], bmp, 0, 0, the_movie->xvid, the_movie->yvid, x[the_movie->mode],
			y[the_movie->mode], w[the_movie->mode], h[the_movie->mode]);
	}

	// play audio, if exists
	mjpga_audio_play(the_movie);

	// start the timer with 0
	timer_movie = 0;

	// main loop
	while(1) {
		// poll the audio
		mjpga_audio_poll(the_movie);
		if(timer_movie) {
			if(update_movie_frame_avi()) {
				break;
			}
			avi_read_frame_video(avi, the_movie->frame);
			if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
				// normal and center mode use blit (can be vram -> vram accelerated)
				r = load_memory_avi_xvid_ex(avi->avi_s[avi->video_stream]->buffer, vid[0]);
			}
			else {
				// others, use stretch_blit
				r = load_memory_avi_xvid_ex(avi->avi_s[avi->video_stream]->buffer, vid[1]);
			}
			if(r) {
				// error
				destroy_bitmap(vid[0]);
				if(vid[1] != vid[0]) {
					destroy_bitmap(vid[1]);
				}
				if(temp) {
					destroy_bitmap(bmp);
					bmp = temp;
					show_video_bitmap(bmp);
				}
				close_movie();
				return 1;
			}
			if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
				// normal and center mode use blit (can be vram -> vram accelerated)
				blit(vid[0], bmp, 0, 0, x[the_movie->mode], y[the_movie->mode], the_movie->xvid, the_movie->yvid);
			}
			else {
				// others, use stretch_blit
				stretch_blit(vid[1], bmp, 0, 0, the_movie->xvid, the_movie->yvid, x[the_movie->mode],
					y[the_movie->mode], w[the_movie->mode], h[the_movie->mode]);
			}
		}
		if(callback != NULL) {
			if(callback() != 0) {
				break;
			}
		}
	}
	// free the memory used in bitmaps
	destroy_bitmap(vid[0]);
	if(vid[1] != vid[0]) {
		destroy_bitmap(vid[1]);
	}
	if(temp) {
		destroy_bitmap(bmp);
		bmp = temp;
		show_video_bitmap(bmp);
	}
	close_movie();
	return 0;
}


/*! \brief Function to open an avi.
 *
 *  If the extension of \a file is .avi, this function is called.
 *
 *  It will open the avi file, and check if the video codec are supported. If
 *  supported, add the codec to the \link MJPGA_MOVIE::subtype subtype 
 *  \endlink of the movie.
 *
 *  It supports video encoded with XviD/DivX.
 *  \return 1 on error, 0 ok
 *  \sa open_movie(), open_movie_dat()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : 04/04/2003
 */
int open_movie_avi(AL_CONST char *file)
{
	AVI_MOVIE *avi;
	int i;
	// to convert the file name to ascii
	int size;
	char *ascii;

	// destroy the current movie, if it exists
	if(the_movie)
		close_movie();
	// alloc the memory
	init_movie();
	// convert to ascii
	size = uconvert_size(file, U_CURRENT, U_ASCII);
	ascii = (char *)malloc(size);
	do_uconvert(file, U_CURRENT, ascii, U_ASCII, size);
	// load the avi
	the_movie->movie = avi_open(ascii);
	if(the_movie->movie == NULL) {
		close_movie();
		return 1;
	}
	// free ascii string
	free(ascii);

	// set the movie attributes
	the_movie->type = MJPGAT_AVI;

	avi = (AVI_MOVIE *)the_movie->movie;
	the_movie->xvid = avi->avi_mh.width;
	the_movie->yvid = avi->avi_mh.height;
	for(i=0; i<avi->avi_mh.streams; i++) {
		if(avi->avi_s[i]->sh.fcctype == FCC_vids) {
			the_movie->fps = (float)avi->avi_s[i]->sh.rate / avi->avi_s[i]->sh.scale;
			the_movie->size = avi->avi_s[i]->sh.length;
			switch(avi->avi_s[i]->sh.fcchandle) {
				case FCC_DIVX :
					the_movie->subtype = MJPGAST_DIVX;
				break;
				case FCC_XVID :
					the_movie->subtype = MJPGAST_XVID;
				break;
				case FCC_DIVX_OTHER :
					the_movie->subtype = MJPGAST_DIVX;
				break;
				// codec not supported
				default :
					close_movie();
					return 1;
				break;
			}
		}
	}
	the_movie->frame = 0;
	strcpy(the_movie->desc, get_filename(file));

	mjpga_audio_open(the_movie);

	return 0;
}


/*! \brief Close the avi file and free the memory.
 *
 *  After close_movie() determines the type of the movie is a avi file, this
 *  function is called.
 *
 *  It will call avi_destroy() to destroy the datafile, and free the
 *  memory allocated to XviD interface.
 *  \return Nothing
 *  \sa close_movie(), close_movie_dat(), dec_stop_xvid()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : 08/03/2003
 */
void close_movie_avi(void)
{
	if(the_movie->movie)
		avi_destroy((AVI_MOVIE *)the_movie->movie);
	mjpga_audio_destroy(the_movie);
	dec_stop_xvid();
	free(the_movie);
}


/*! \brief Jump to current frame in the avi file.
 *
 *  Call this for change to actual movie frame, if the movie is in a avi file.
 *  \return 0 if ok, non zero if end of movie
 *  \sa update_movie_frame_dat()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : -
 */
int update_movie_frame_avi(void)
{
	AVI_MOVIE *avi;

	avi = the_movie->movie;
	while(timer_movie) {
		the_movie->frame++;
		timer_movie--;
		if(the_movie->frame < 0 || the_movie->frame >= the_movie->size)
			return 1;
	}
	return 0;
}




/*! @} */
