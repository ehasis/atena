/*! \addtogroup mjpgadat MJpgAlleg - DAT movie
 *    \brief This file is to help load and play .dat files.
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *    - 30/09/2002 - Start
 *    - 10/10/2002 - Start converting comments to doxygen style
 *    - 03/11/2002 - Bug fixes for version 2.11 (new line at end of file)
 *    - 25/11/2002 - Another bug fix, included string.h
 *    - 08/03/2003 - Updating some functions to use the new way to play sounds.
 *    - 03/04/2003 - Optimized play_movie_dat() to use hardware acceleration.
 *    @{
*/


#include <string.h>
#include <xvid.h>
#include "mjpga.h"
#include "mjpga/mjpgaint.h"


/*! \brief Play a movie from a datafile.
 *
 *  This function is like play_fli(). The movie has been previously opened
 *  with open_movie(), and this function is called if the movie is in a
 *  datafile.
 *
 *  The \a bmp is the destination bitmap, and \a callback, if not NULL, will be
 *  called every time during the execution of the movie.
 *
 *  If callback returns non zero, the movie stops.
 *  \return 1 on error, 0 ok
 *  \sa play_movie(), play_movie_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 01/10/2002
 *  - \p Updated : 04/04/2003
 */
int play_movie_dat(BITMAP *bmp, int (*callback)())
{
	BITMAP *vid[2], *temp;
	int (*load_memory_ex)(void *, BITMAP * );
	DATAFILE *dat;
	int r;
	// used in screen modes
	int x[MJPGAM_TOTAL_MODES], y[MJPGAM_TOTAL_MODES], w[MJPGAM_TOTAL_MODES], h[MJPGAM_TOTAL_MODES];

	// pre-calc to different modes of display
	mjpga_pre_calc_pos(the_movie, bmp->w, bmp->h, x, y, w, h);

	// creating the bitmap, try to use the possible acceleration
	temp = NULL;
	if( (gfx_capabilities & GFX_HW_VRAM_BLIT) && (bmp == screen) && mjpga_is_mul_16(the_movie->xvid) ) {
		// create video bitmaps, if possible
		// note: if the 'bmp' is the screen bitmap, it's needed to be
		// created again, to give the correct output
		temp = screen;
		bmp = create_video_bitmap(SCREEN_W, SCREEN_H);
		if(!bmp) {
			// if not enough video memory, restore the bmp pointer
			temp = NULL;
			bmp = screen;
			// and try system bitmap
			vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid[0]) {
				return 1;
			}
			// because only blits are accelerated, stretch_blit will need a
			// system bitmap
			vid[1] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid[1]) {
				destroy_bitmap(vid[0]);
				return 1;
			}
		}
		else {
			// if enough video memory, try video memory for the bitmap
			// where the decoded frame will be
			vid[0] = create_video_bitmap(the_movie->xvid, the_movie->yvid);
			if(!vid) {
				// if not enough video memory, restore the bmp pointer
				destroy_bitmap(bmp);
				bmp = temp;
				temp = NULL;
				// and try system bitmap
				vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
				if(!vid[0]) {
					return 1;
				}
				// because only blits are accelerated, stretch_blit will need a
				// system bitmap
				vid[1] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
				if(!vid[1]) {
					destroy_bitmap(vid[0]);
					return 1;
				}
			}
			else {
				// because only blits are accelerated, stretch_blit will need a
				// system bitmap
				vid[1] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
				if(!vid[1]) {
					destroy_bitmap(bmp);
					bmp = temp;
					temp = NULL;
					destroy_bitmap(vid[0]);
					return 1;
				}
				show_video_bitmap(bmp);
			}
		}
	}
	else {
		// bmp isn't the screen (unusual)
		vid[0] = create_system_bitmap(the_movie->xvid, the_movie->yvid);
		if(!vid[0]) {
			return 1;
		}
		vid[1] = vid[0];
	}

	// choose what 'load_memory' will use
	load_memory_ex = NULL;
	switch(the_movie->subtype) {
		case MJPGAST_JPG :
			// the data is a jpeg
			load_memory_ex = load_memory_jpg_ex;
		break;
		case MJPGAST_M4V :
			// the data is a mpeg 4 video
			load_memory_ex = load_memory_dat_xvid_ex;
			// start the decoder
			dec_init_xvid();
		break;
		default :
			// unknow subtype, try to use mpeg 4 decoder
			load_memory_ex = load_memory_dat_xvid_ex;
		break;
	}

	// aux pointer
	dat = (DATAFILE *)the_movie->movie;

	// load first frame
	if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
		// normal and center mode use blit (can be vram -> vram accelerated)
		r = load_memory_ex(dat[the_movie->frame].dat, vid[0]);
	}
	else {
		// others, use stretch_blit
		r = load_memory_ex(dat[the_movie->frame].dat, vid[1]);
	}
	if(r) {
		// error
		destroy_bitmap(vid[0]);
		if(vid[1] != vid[0]) {
			destroy_bitmap(vid[1]);
		}
		if(temp) {
			destroy_bitmap(bmp);
			bmp = temp;
			show_video_bitmap(bmp);
		}
		close_movie();
		return 1;
	}
	if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
		// normal and center mode use blit (can be vram -> vram accelerated)
		blit(vid[0], bmp, 0, 0, x[the_movie->mode], y[the_movie->mode], the_movie->xvid, the_movie->yvid);
	}
	else {
		// others, use stretch_blit
		stretch_blit(vid[1], bmp, 0, 0, the_movie->xvid, the_movie->yvid, x[the_movie->mode],
			y[the_movie->mode], w[the_movie->mode], h[the_movie->mode]);
	}

	// play audio, if exists
	mjpga_audio_play(the_movie);

	// start the timer with 0
	timer_movie = 0;

	// main loop
	while(1) {
		// poll the audio
		mjpga_audio_poll(the_movie);
		if(timer_movie) {
			if(update_movie_frame_dat())
				break;
			if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
				// normal and center mode use blit (can be vram -> vram accelerated)
				r = load_memory_ex(dat[the_movie->frame].dat, vid[0]);
			}
			else {
				// others, use stretch_blit
				r = load_memory_ex(dat[the_movie->frame].dat, vid[1]);
			}
			if(r) {
				// error
				destroy_bitmap(vid[0]);
				if(vid[1] != vid[0]) {
					destroy_bitmap(vid[1]);
				}
				if(temp) {
					destroy_bitmap(bmp);
					bmp = temp;
					show_video_bitmap(bmp);
				}
				close_movie();
				return 1;
			}
			if(the_movie->mode == MJPGAM_NORMAL || the_movie->mode == MJPGAM_CENTER) {
				// normal and center mode use blit (can be vram -> vram accelerated)
				blit(vid[0], bmp, 0, 0, x[the_movie->mode], y[the_movie->mode], the_movie->xvid, the_movie->yvid);
			}
			else {
				// others, use stretch_blit
				stretch_blit(vid[1], bmp, 0, 0, the_movie->xvid, the_movie->yvid, x[the_movie->mode],
					y[the_movie->mode], w[the_movie->mode], h[the_movie->mode]);
			}
		}
		if(callback != NULL) {
			if(callback() != 0) {
				break;
			}
		}
	}
	// free the memory used in bitmaps
	destroy_bitmap(vid[0]);
	if(vid[1] != vid[0]) {
		destroy_bitmap(vid[1]);
	}
	if(temp) {
		destroy_bitmap(bmp);
		bmp = temp;
		show_video_bitmap(bmp);
	}
	close_movie();
	return 0;
}


/*! \brief Function to open a datafile.
 *
 *  If the extension of \a file is .dat, this function is called.
 *
 *  It will open the datafile, search for the subtype of the movie (jpg or
 *  m4v), search the sample and search for a object of type 'INFO',
 *  with information about dimensions of frame, fps, description, etc.
 *
 *  Because version 1.0 don't have the width and the height of the frames,
 *  if these variables aren't presents, the function tries to determine the
 *  dimensions of the frame using load_memory_jpeg().
 *  \return 1 on error, 0 ok
 *  \sa open_movie(), open_movie_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : 08/03/2003
 */
int open_movie_dat(AL_CONST char *file)
{
	BITMAP *temp;
	DATAFILE *dat;
	int i;

	// destroy the current movie, if it exists
	if(the_movie)
		close_movie();
	// alloc the memory
	init_movie();
	// point to the datafile
	(DATAFILE *)the_movie->movie = load_datafile(file);
	if(the_movie->movie == NULL) {
		close_movie();
		return 1;
	}

	the_movie->type = MJPGAT_DAT;
	dat = (DATAFILE *)the_movie->movie;

	// search for the sample and the jpg's or m4v's
	for(i=0; dat[i].type != DAT_END; i++) {
		switch(dat[i].type) {
			case MJPGAST_JPG :
				if(the_movie->frame < 0) {
					the_movie->frame = i;
					the_movie->subtype = MJPGAST_JPG;
				}
				the_movie->size++;
			break;
			case MJPGAST_M4V :
				if(the_movie->frame < 0) {
					the_movie->frame = i;
					the_movie->subtype = MJPGAST_M4V;
				}
				the_movie->size++;
			break;
			case DAT_ID('I', 'N', 'F', 'O') :
				push_config_state();
				set_config_data((const char *)dat[i].dat, dat[i].size);
				the_movie->fps = get_config_float(NULL, "fps", -1);
				the_movie->xvid = get_config_int(NULL, "XDIM", -1);
				the_movie->yvid = get_config_int(NULL, "YDIM", -1);
				strcpy(the_movie->desc, get_config_string(NULL, "desc", empty_string));
				pop_config_state();
			default :
			break;
		}
	}
	// if fps is invalid, then the movie is invalid
	if(the_movie->fps < 0) {
		close_movie();
		return 1;
	}
	// if xvid or yvid = 0, try to determine the size of each frame
	if(the_movie->xvid < 0 || the_movie->yvid < 0) {
		if(the_movie->subtype == MJPGAST_JPG) {
			temp = load_memory_jpg(dat[the_movie->frame].dat, NULL);
			the_movie->xvid = temp->w;
			the_movie->yvid = temp->h;
			destroy_bitmap(temp);
		}
		else {
			close_movie();
			return 1;
		}
	}
	the_movie->last_frame = the_movie->frame;
	// try to load the audio
	mjpga_audio_open(the_movie);
	return 0;
}


/*! \brief Close the datafile and free the memory.
 *
 *  After close_movie() determines the type of the movie is a datafile, this
 *  function is called.
 *
 *  It will call unload_datafile() to destroy the datafile, and free the
 *  memory allocated to XviD interface.
 *  \return Nothing
 *  \sa close_movie(), close_movie_avi(), dec_stop_xvid()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : 14/03/2003
 */
void close_movie_dat(void)
{
	if(the_movie->movie)
		unload_datafile((DATAFILE *)the_movie->movie);
	mjpga_audio_destroy(the_movie);
	free(the_movie);
	dec_stop_xvid();
}


/*! \brief Jump to current frame in a datafile.
 *
 *  Call this for change to actual movie frame, if the movie is in a datafile.
 *  \return 0 if ok, non zero if end of movie
 *  \sa update_movie_frame_avi()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 30/09/2002
 *  - \p Updated : -
 */
int update_movie_frame_dat(void)
{
	DATAFILE *dat;

	dat = (DATAFILE *)the_movie->movie;
	while(timer_movie) {
		if(dat[the_movie->frame].type == the_movie->subtype) {
			the_movie->frame++;
			timer_movie--;
		}
		if(the_movie->frame < 0 || the_movie->frame >= the_movie->size)
			return 1;
		else if(dat[the_movie->frame].type == DAT_END)
			return 2;
	}
	return 0;
}


/*! @} */
