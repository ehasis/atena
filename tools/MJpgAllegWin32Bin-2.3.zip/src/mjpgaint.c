/*! \addtogroup mjpgaint MJpgAlleg - Internal
 *    \brief This files is for the internal functions
 *
 *    \author Eduardo "Dudaskank"
 *
 *    \date
 *    - 19/09/2002 - Start
 *    - 11/10/2002 - Start converting comments to doxygen style
 *    - 03/11/2002 - Bug fixes for version 2.11 (new line at end of file)
 *    - 09/03/2003 - Optimization for decoding to bitmaps
 *    - 14/03/2003 - Great improve in decoder speed (decoding now is derectly to
 *    bitmap).
 *    - 02~03/04/2003 - Creating the load_*_ex() to can use hardware acceleration
 *    @{
*/

#include <string.h>
#include <xvid.h>
#include "mjpga.h"
#include "mjpga/mjpgaint.h"


/*! \hideinitializer \brief Parameters of the decoder */
static void *dechandle = NULL;
/* colorspace to be decoded */
static int xvid_colorspace;
/* conversion functions from bgr to bitmap */
static void bgr_to_bitmap24(BITMAP *bmp);
/* pointer to conversion function */
static void (*bgr_to_bitmap)(BITMAP *bmp);


/*! \brief Init the XviD decoder.
 *
 *  This function will fill the decoder with the movie parameters.
 *
 *  Also, select the color space to be decoded, based on the current color depth
 *  of the screen bitmap. Remember, don't use 8 bpp!
 *
 *  \return 0 if ok, non zero if error
 *  \sa dec_stop_xvid()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 03/10/2002
 *  - \p Updated : 14/03/2003
 */
int dec_init_xvid(void)
{
	int xerr;
	
	XVID_INIT_PARAM xinit;
	XVID_DEC_PARAM xparam;

	xinit.cpu_flags = 0;
	xvid_init(NULL, 0, &xinit, NULL);
	xparam.width = the_movie->xvid;
	xparam.height = the_movie->yvid;

	xerr = xvid_decore(NULL, XVID_DEC_CREATE, &xparam, NULL);
	dechandle = xparam.handle;

	// choose the proper function to convert from bgr to bitmap, based on current bpp
	switch(bitmap_color_depth(screen)) {
		case 8 :
			xvid_colorspace = XVID_CSP_NULL;
			return 1;
		break;
		case 15 :
			bgr_to_bitmap = NULL;
			xvid_colorspace = XVID_CSP_RGB555;
		break;
		case 16 :
			bgr_to_bitmap = NULL;
			xvid_colorspace = XVID_CSP_RGB565;
		break;
		case 24 :
			bgr_to_bitmap = bgr_to_bitmap24;
			xvid_colorspace = XVID_CSP_RGB24;
		break;
		case 32 :
			bgr_to_bitmap = NULL;
			xvid_colorspace = XVID_CSP_RGB32;
		break;
	}

	return xerr;
}


/*! \brief Stop the XviD decoder
 *
 *  This function just destroy dechandle
 *  \return 0 if ok, non zero if error
 *  \sa dec_init_xvid()
 *
 *  \date
 *  - \p Created : 03/10/2002
 *  - \p Updated : 14/03/2003
 */
int dec_stop_xvid(void)
{
	int xerr = 0;
	if(dechandle) {
		xerr = xvid_decore(dechandle, XVID_DEC_DESTROY, NULL, NULL);
		dechandle = NULL;
	}

	return xerr;
}


/*! \brief Convert from bgr format to allegro bitmap with 24 bpp.
 *
 *  The \bmp is the destiny bitmap, previously created with the width and
 *  the height of the frame.
 *  \date
 *  - \p Created : 08/03/2003
 *  - \p Updated : 14/03/2003
 */
void bgr_to_bitmap24(BITMAP *bmp)
{
	int i, j, pos;
	unsigned char r, g, b;
	unsigned char *decimage;

	acquire_bitmap(bmp);
	decimage = (unsigned char *)bmp_read_line(bmp, 0);
	pos = 0;
	for(i = 0; i < bmp->h; i++) {
		for(j = 0; j < bmp->w; j++) {
			b = *(decimage + pos++);
			g = *(decimage + pos++);
			r = *(decimage + pos++);
			_putpixel24(bmp, j, i, makecol24(r, g, b));
		}
	}
	bmp_unwrite_line(bmp);
	release_bitmap(bmp);
}


/*! \brief Wrapper to load a jpeg frame from datafiles direct to a bitmap.
 *
 *  Parameter \a data is the memory containing the jpeg, and \a dest is the
 *  destiny bitmap.
 *
 *  \return 0 if ok, not 0 if error
 *  \sa load_memory_avi_xvid(), load_memory_avi_xvid_ex(), load_memory_dat_xvid(), load_memory_dat_xvid_ex()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 03/04/2002
 *  - \p Updated : 03/04/2003
 */

int load_memory_jpg_ex(void *data, BITMAP *dest)
{
	BITMAP *temp;
	temp = load_memory_jpg(data, NULL);
	if(!temp) {
		// invalid jpg
		return 1;
	}
	blit(temp, dest, 0, 0, 0, 0, dest->w, dest->h);
	destroy_bitmap(temp);
	return 0;
}


/*! \brief Function to handle the load of a XviD/DivX frame from datafiles.
 *
 *  Variable \a data is the memory to load, and \a pal will be the palette,
 *  only for compability with other Allegro functions (load_bitmap(), ...),
 *  because this variable don't change.
 *
 *  The size of m4v is determined looking into the current object in datafile
 *  for the property \a size.
 *
 *  The m4v in the memory \b must be encoded with XviD or DivX 5. If you
 *  don't have these codecs, you can download it in \link
 *  http://www.divx-digest.com DivX Digest \endlink.
 *
 *  \return Pointer to the bitmap on sucess, NULL on error
 *  \sa load_memory_avi_xvid(), load_memory_avi_xvid_ex(), load_memory_dat_xvid_ex(), load_memory_jpg_ex()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 01/10/2002
 *  - \p Updated : 03/04/2003
 */
BITMAP *load_memory_dat_xvid(void *data, RGB *pal)
{
	BITMAP *bmp;

	// alloc the bitmap
	bmp = create_system_bitmap(the_movie->xvid, the_movie->yvid);
	if(!bmp) {
		return NULL;
	}

	if(load_memory_dat_xvid_ex(data, bmp)) {
		destroy_bitmap(bmp);
		return NULL;
	}
	(void)pal;

	return bmp;
}


/*! \brief Function to handle the load of a XviD/DivX frame from datafiles
 *  direct to a bitmap.
 *
 *  Variable \a data is the memory to load, and \a dest is the bitmap where
 *  the frame will be decoded. It can't be a sub-bitmap!
 *
 *  The size of m4v is determined looking into the current object in datafile
 *  for the property \a size.
 *
 *  The frame in the memory \b must be encoded with XviD or DivX. If you
 *  don't have these codecs, you can download it in \link
 *  http://www.divx-digest.com DivX Digest \endlink.
 *  \return Pointer to the bitmap on sucess, NULL on error
 *  \sa load_memory_avi_xvid(), load_memory_avi_xvid_ex(), load_memory_dat_xvid(), load_memory_jpg_ex()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 03/04/2003
 *  - \p Updated : 03/04/2003
 */
int load_memory_dat_xvid_ex(void *data, BITMAP *dest)
{
	int xerr;
	XVID_DEC_FRAME xframe;
	DATAFILE *dat;

	dat = (DATAFILE *)the_movie->movie;
	// initialize the dec_frame struct
	xframe.stride = the_movie->xvid;
	// if necessary, skip some frames for slow computers
	while(the_movie->last_frame + 1 < the_movie->frame) {
		the_movie->last_frame++;
		xframe.bitstream = dat[the_movie->last_frame].dat;
		xframe.length = dat[the_movie->last_frame].size;
		xframe.colorspace = XVID_CSP_NULL;
		xerr = xvid_decore(dechandle, XVID_DEC_DECODE, &xframe, NULL);
		if(xerr) {
			// invalid frame
			return 1;
		}
	}
	// initialize the dec_frame struct with the actual frame data
	xframe.bitstream = data;
	xframe.length = dat[the_movie->frame].size;
	// XVID_CSP_USER is fastest (no memcopy involved)
	xframe.colorspace = xvid_colorspace;

	xframe.image = (void *)bmp_write_line(dest, 0);
	// decode the frame
	xerr = xvid_decore(dechandle, XVID_DEC_DECODE, &xframe, NULL);
	bmp_unwrite_line(dest);
	if(xerr) {
		// error decoding
		return 1;
	}

	// convert if needed
	if(bgr_to_bitmap) {
		bgr_to_bitmap(dest);
	}

	// update the content of last_frame
	the_movie->last_frame = the_movie->frame;
	return 0;
}


/*! \brief Function to handle the load of a XviD/DivX frame from avi files.
 *
 *  Variable \a data is the memory to load, and \a pal will be the palette,
 *  only for compability with other Allegro functions (load_bitmap(), ...),
 *  because this variable don't change.
 *
 *  The size of m4v is determined looking into property \link
 *  AVI_MOVIE::frame_video frame_video \endlink of AVI_MOVIE.
 *
 *  The frame in the memory \b must be encoded with XviD or DivX. If you
 *  don't have these codecs, you can download it in \link
 *  http://www.divx-digest.com DivX Digest \endlink.
 *  \return Pointer to the bitmap on sucess, NULL on error
 *  \sa load_memory_avi_xvid_ex(), load_memory_dat_xvid(), load_memory_avi_xvid_ex(), load_memory_jpg_ex()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 01/10/2002
 *  - \p Updated : 03/04/2003
 */
BITMAP *load_memory_avi_xvid(void *data, RGB *pal)
{
	BITMAP *bmp;

	// alloc the bitmap
	bmp = create_system_bitmap(the_movie->xvid, the_movie->yvid);
	if(!bmp) {
		return NULL;
	}

	if(load_memory_avi_xvid_ex(data, bmp)) {
		destroy_bitmap(bmp);
		return NULL;
	}
	(void)pal;

	return bmp;
}


/*! \brief Function to handle the load of a XviD/DivX frame from avi files
 *  direct to a bitmap.
 *
 *  Variable \a data is the memory to load, and \a dest is the bitmap where
 *  the frame will be decoded. It can't be a sub-bitmap!
 *
 *  The size of m4v is determined looking into property \link
 *  AVI_MOVIE::frame_video frame_video \endlink of AVI_MOVIE.
 *
 *  The frame in the memory \b must be encoded with XviD or DivX. If you
 *  don't have these codecs, you can download it in \link
 *  http://www.divx-digest.com DivX Digest \endlink.
 *  \return Pointer to the bitmap on sucess, NULL on error
 *  \sa load_memory_avi_xvid(), load_memory_dat_xvid(), load_memory_dat_xvid_ex(), load_memory_jpg_ex()
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 02/04/2003
 *  - \p Updated : 02/04/2003
 */
int load_memory_avi_xvid_ex(void *data, BITMAP *dest)
{
	int xerr;
	XVID_DEC_FRAME xframe;
	AVI_MOVIE *avi;
	void *temp = NULL;
	short int reread = 0;

	avi = (AVI_MOVIE *)the_movie->movie;
	// initialize the dec_frame struct
	xframe.stride = the_movie->xvid;
	// if necessary, skip some frames for slow computers
	while(the_movie->last_frame + 1 < the_movie->frame) {
		if(the_movie->last_frame < 0)
			break;
		the_movie->last_frame++;
		// if it is the first time, save the buffer position and create a new one
		if(!reread) {
			// to restore the buffer after skiping the frames
			reread = 1;
			// save the actual buffer position
			temp = avi->avi_s[avi->video_stream]->buffer;
			// generating new buffer
			avi->avi_s[avi->video_stream]->buffer = malloc(avi->avi_s[avi->video_stream]->sh.sbufsize);
		}
		// reading in the new buffer
		avi_read_frame_video(avi, the_movie->last_frame);
		xframe.bitstream = avi->avi_s[avi->video_stream]->buffer;
		xframe.length = avi->avi_s[avi->video_stream]->frame_size;
		// skiping the frame
		xframe.colorspace = XVID_CSP_NULL;
		xerr = xvid_decore(dechandle, XVID_DEC_DECODE, &xframe, NULL);
		if(xerr) {
			free(avi->avi_s[avi->video_stream]->buffer);
			avi->avi_s[avi->video_stream]->buffer = temp;
			return xerr;
		}
	}

	if(reread) {
		// repositioning the buffer
		free(avi->avi_s[avi->video_stream]->buffer);
		avi->avi_s[avi->video_stream]->buffer = temp;
	}
	// initialize the dec_frame struct with the actual frame data
	xframe.bitstream = data;
	xframe.length = avi->avi_s[avi->video_stream]->frame_size;
	// XVID_CSP_USER is fastest (no memcopy involved)
	xframe.colorspace = xvid_colorspace;

	xframe.image = (void *)bmp_write_line(dest, 0);
	// decode the frame
	xerr = xvid_decore(dechandle, XVID_DEC_DECODE, &xframe, NULL);
	bmp_unwrite_line(dest);
	if(xerr) {
		return xerr;
	}

	// convert if needed
	if(bgr_to_bitmap) {
		bgr_to_bitmap(dest);
	}

	// update the content of last_frame
	the_movie->last_frame = the_movie->frame;

	return 0;
}


/*! \brief Function to pre-calc the position and size for every possible display mode.
 *
 *  The parameter \a movie is a previously openned movie, \a bmpw and \a bmph are the bitmap
 *  width and height, respectively, and \a x[], \a y[], \a w[] and \a h[] are the places to
 *  store the positions and size for each mode.
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 04/04/2003
 *  - \p Updated : 04/04/2003
 */
void mjpga_pre_calc_pos(MJPGA_MOVIE *movie, int bmpw, int bmph, int x[MJPGAM_TOTAL_MODES],
	int y[MJPGAM_TOTAL_MODES], int w[MJPGAM_TOTAL_MODES], int h[MJPGAM_TOTAL_MODES])
{
	float f;

	// for MJPGAM_NORMAL:
	x[MJPGAM_NORMAL] = 0;
	y[MJPGAM_NORMAL] = 0;
	w[MJPGAM_NORMAL] = bmpw;
	h[MJPGAM_NORMAL] = bmph;

	// for MJPGAM_FULL:
	f = MIN((float)bmpw/movie->xvid, (float)bmph/movie->yvid);
	w[MJPGAM_FULL] = (int)(movie->xvid * f);
	h[MJPGAM_FULL] = (int)(movie->yvid * f);
	x[MJPGAM_FULL] = (int)((bmpw-w[MJPGAM_FULL])/2);
	y[MJPGAM_FULL] = (int)((bmph-h[MJPGAM_FULL])/2);

	// for MJPGAM_CENTER:
	x[MJPGAM_CENTER] = (int)((bmpw-movie->xvid)/2);
	y[MJPGAM_CENTER] = (int)((bmph-movie->yvid)/2);
	w[MJPGAM_CENTER] = bmpw;
	h[MJPGAM_CENTER] = bmph;

	// for MJPGAM_HALF:
	f = 0.5;
	w[MJPGAM_HALF] = (int)(movie->xvid * f);
	h[MJPGAM_HALF] = (int)(movie->yvid * f);
	x[MJPGAM_HALF] = (int)((bmpw-w[MJPGAM_HALF])/2);
	y[MJPGAM_HALF] = (int)((bmph-h[MJPGAM_HALF])/2);

	// for MJPGAM_DOUBLE:
	f = 2.0;
	w[MJPGAM_DOUBLE] = (int)(movie->xvid * f);
	h[MJPGAM_DOUBLE] = (int)(movie->yvid * f);
	x[MJPGAM_DOUBLE] = (int)((bmpw-w[MJPGAM_DOUBLE])/2);
	y[MJPGAM_DOUBLE] = (int)((bmph-h[MJPGAM_DOUBLE])/2);
}


/*! \brief Function to say if the number is multiply by 16.
 *
 *  This function is needed because (at least my) create_video_bitmap() uses
 *  always multiplies by 16.
 *
 *  The parameter \a n is the number.
 *
 *  \return 0 if isn't, otherwise if is
 *  \author Eduardo "Dudaskank"
 *  \date
 *  - \p Created : 04/04/2003
 *  - \p Updated : 04/04/2003
 */
int mjpga_is_mul_16(int n)
{
	return !(n & 0xF);
}


/*! @} */
