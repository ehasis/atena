/* Tool to convert AVI files in datafiles, which MJpgAlleg can play */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <allegro.h>
#include <almp3.h>
#include "mjpga.h"
#include "savedat.h"

#define MAX_ARQ		512
#define CF1				makecol(0, 0, 0)				// cor do texto
#define CF2				makecol(32, 32, 32)			// cor de texto para objetos em foco
#define CB0				makecol(0, 128, 192)			// cor do fundo da tela
#define CB1				makecol(222, 222, 222)		// cor do fundo do di�logo
#define CB2				makecol(255, 255, 255)		// cor do fundo do bot�o e do texto
#define CB3				makecol(224, 255, 224)		// cor de fundo de objetos com o foco


static void mostra_info(AVI_MOVIE *avi);
static int seleciona_avi(char arquivo[]);
static void salva_video(AVI_MOVIE *avi);
static void progresso(int n, int max);
static void toca_wav(AVI_MOVIE *avi);
static SAMPLE *gera_sample(AVI_MOVIE *avi);
static void *gera_mp3(AVI_MOVIE *avi, int *tamanho);
static int salva_cb(void);

// para o GUI ficar mais bonitinho ^__^
static int meu_shadow_box(int msg, DIALOG *d, int c);
static int meu_ctext(int msg, DIALOG *d, int c);
static int meu_edit(int msg, DIALOG *d, int c);
static int meu_button(int msg, DIALOG *d, int c);
static int meu_list(int msg, DIALOG *d, int c);
static int meu_text_list(int msg, DIALOG *d, int c);
static int meu_textbox(int msg, DIALOG *d, int c);


char arquivo[MAX_ARQ];			// nome do arquivo
int prog_max;						// vari�vel para guardar o valor m�ximo do progresso
int prog_n;							// progresso atual
char prog_msg[4][80] = {
	"Making info...",
	"Making audio...",
	"Making video...",
	"Saving to datafile..."
};


int main(void)
{
	AVI_MOVIE *avi;
	int ok;
	int gfx = GFX_AUTODETECT_WINDOWED, w = 640, h = 480, bpp = 16;

	strcpy(arquivo, "./");

	set_uformat(U_ASCII);
	allegro_init();
	install_keyboard();
	install_timer();
	install_mouse();
	install_sound(DIGI_AUTODETECT, MIDI_NONE, "");
	set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

	set_palette(default_palette);
	// muda as fun��es padr�o do GUI
	gui_shadow_box_proc = meu_shadow_box;
	gui_ctext_proc = meu_ctext;
	gui_edit_proc = meu_edit;
	gui_button_proc = meu_button;
	gui_list_proc = meu_list;
	gui_text_list_proc = meu_text_list;

	clear_to_color(screen, CB0);
	ok = gfx_mode_select_ex(&gfx, &w, &h, &bpp);
	if(!ok)
		return EXIT_SUCCESS;
	set_color_depth(bpp);
	if(set_gfx_mode(gfx, w, h, 0, 0)) {
		set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
		allegro_message("Erro ao entrar no modo gr�fico!\n%s", allegro_error);
		return EXIT_FAILURE;
	}
	if(bpp == 8) {
		set_palette(default_palette);
	}

	clear_to_color(screen, CB0);
	text_mode(CB0);
	show_mouse(screen);

	set_config_file("./avi2dat.cfg");
	strcpy(arquivo, get_config_string(NULL, "ultimo_diretorio", "./"));

	do {
		ok = seleciona_avi(arquivo);
		if(ok) {
			if(!exists(arquivo)) {
				alert("Arquivo n�o existe", "N�o deu certo �__�", "", "OK", NULL, 13, 0);
			}
			avi = avi_open(arquivo);
			if(!avi) {
				alert("Erro ao abrir arquivo", "N�o deu certo �__�", "", "OK", NULL, 13, 0);
			}
			mostra_info(avi);
			avi_destroy(avi);
		}
	} while(ok);

	replace_filename(arquivo, arquivo, "", MAX_ARQ);
	set_config_string(NULL, "ultimo_diretorio", arquivo);
	return EXIT_SUCCESS;
}
END_OF_MAIN();


static void mostra_info(AVI_MOVIE *avi)
{
	// ponteiros para facilitar na digita��o
	AVI_MAIN_HEADER *mh;
	AVI_STREAM *s;
	AVI_STREAM_HEADER *sh;
	// para mostrar o fcc como string
	union { int i; char str[5]; } fcc1, fcc2;
	int i;
	// onde ser� copiado o texto do di�logo
	char texto[1048576];
	// di�logo principal
	DIALOG d[] = {
		{ meu_shadow_box, 0, 0, SCREEN_W*0.7, SCREEN_H*0.7, CF1, CB1, 0, 0, 0, 0, NULL, NULL, NULL },
		{ meu_textbox, 10, 10, SCREEN_W*0.7-20, SCREEN_H*0.7-50, CF1, CB2, 0, 0, 0, 0, texto, NULL, NULL },
		{ meu_button, 10, SCREEN_H*0.7-30, SCREEN_W*0.2, 20, CF1, CB2, 13, D_EXIT, 0, 0, "OK", NULL, NULL },
		{ meu_button, 20+SCREEN_W*0.2, SCREEN_H*0.7-30, SCREEN_W*0.2, 20, CF1, CB2, 13, D_EXIT, 0, 0, "Save to datafile", NULL, NULL },
		{ meu_button, 30+SCREEN_W*0.4, SCREEN_H*0.7-30, SCREEN_W*0.2, 20, CF1, CB2, 13, D_EXIT, 0, 0, "Play wav", NULL, NULL },
		{ NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL }
	};
	centre_dialog(d);
	mh = &avi->avi_mh;
	sprintf(texto, "%s\n\nMicroseconds per frame = %d\n"
			  "Max bytes per second = %d\n"
			  "Flags = %d\n"
			  "Total of frames = %d\n"
			  "Ini frames = %d\n"
			  "Streams = %d\n"
			  "Suggested buffer size = %d\n"
			  "X = %d\n"
			  "Y = %d\n"
			  "Scale = %d\n"
			  "Rate = %d\n"
			  "Start = %d\n"
			  "Size = %d\n", get_filename(arquivo), mh->microsecpf, mh->maxbytesps, mh->flags, mh->frames,
			  mh->iniframes, mh->streams, mh->sbufsize, mh->width, mh->height, mh->scale, mh->rate,
			  mh->start, mh->length);
	sprintf(texto, "%s\n\n--------==========--------\n\n\n", texto);

	fcc1.str[4] = fcc2.str[4] = 0;
	for(i=0; i<avi->avi_mh.streams; i++) {
		s = avi->avi_s[i];
		sh = &s->sh;
		fcc1.i = sh->fcctype;
		fcc2.i = sh->fcchandle;
		sprintf(texto, "%sStream = %d\nChunk 'strh':\n"
				  "\tType = %s\n"
				  "\tFCC handle = %s\n"
				  "\tFlags = %d\n"
				  "\tIni frames = %d\n"
				  "\tScale = %d\n"
				  "\tRate = %d\n"
				  "\tRate/Scale = %f\n"
				  "\tStart = %d\n"
				  "\tLength = %d\n"
				  "\tSuggested buffer size = %d\n"
				  "\tQuality = %d\n"
				  "\tSize of sample = %d\n\n", texto,
				  i, fcc1.str, fcc2.str, sh->flags, sh->iniframes, sh->scale, sh->rate, (float)sh->rate/sh->scale,
				  sh->start, sh->length, sh->sbufsize, sh->quality, sh->samplesize);
		sprintf(texto, "%sSize of chunk 'strf' = %d\n\n", texto, s->sf.size);
		sprintf(texto, "%sSize of chunk 'strd' = %d\n\n", texto, s->sd.size);
	sprintf(texto, "%s\n\n--------------------------\n\n\n", texto);
	}
	sprintf(texto, "%smovi offset = %d\n\n", texto, avi->movi_offset);
	sprintf(texto, "%s\n\n--------==========--------\n\n\n", texto);

	i = popup_dialog(d, -1);
	if(i == 3)  {
		salva_video(avi);
	}
	else if(i == 4) {
		toca_wav(avi);
	}
}


static int seleciona_avi(char arquivo[])
{
	return file_select_ex("Choose the file .avi", arquivo, "AVI", MAX_ARQ, SCREEN_W*0.8, SCREEN_H*0.8);
}

static void salva_video(AVI_MOVIE *avi)
{
	SAMPLE *wav;
	int video_size = 0;
	int i, ok;
	char caminho[MAX_ARQ], arq[MAX_ARQ];

	strcpy(caminho, arquivo);
	ok = file_select_ex("Escolha o .dat de destino:", caminho, "DAT", MAX_ARQ, SCREEN_W*0.7, SCREEN_H*0.7);
	if(ok) {
		clear_to_color(screen, CB0);

		// se n�o encontrou a stream de v�deo imprime uma mensagem e sai
		if(avi->video_stream < 0) {
			alert("N�o foi encontrada", "a stream de v�deo!", "", ":-(", NULL, 13, 0);
			return;
		}

		// tamanho do v�deo, em quadros
		video_size = avi->avi_s[avi->video_stream]->sh.length;
		// prepara a barra de progresso
		prog_max = (video_size + 2) * 2;
		prog_n = 0;
		// desenha a primeira barra
		progresso(prog_n, prog_max);

		// cria o arquivo de configura��o para o filme
		push_config_state();
		replace_extension(arq, caminho, "inf", MAX_ARQ);
		set_config_file(arq);

		// seta o fps
		set_config_float(NULL, "fps", (float)avi->avi_s[avi->video_stream]->sh.rate / avi->avi_s[avi->video_stream]->sh.scale);
		set_config_int(NULL, "XDIM", avi->avi_mh.width);
		set_config_int(NULL, "YDIM", avi->avi_mh.height);
		set_config_string(NULL, "Desc", get_filename(arquivo));
		pop_config_state();

		// inicia a cria��o do datafile
		savedat_start(caminho, NULL);
		savedat_insert_file(arq, "INFO");
		delete_file(arq);

		if(salva_cb()) {
			savedat_cancel();
			return;
		}

		// gera e grava o sample
		wav = gera_sample(avi);
		if(!wav) {
			// tenta salvar como mp3, se for o formato
			void *mp3;
			int tamanho;
			mp3 = gera_mp3(avi, &tamanho);
			if(!mp3) {
				alert("Audio can't be saved!", "", "", NULL, "OK", 13, 0);
			}
			else {
				savedat_insert_object(mp3, tamanho, "AUDIO", "MP3 ");
			}
		}
		else {
			savedat_insert_object((void *)wav, 0, "AUDIO", "SAMP");
		}

		if(salva_cb()) {
			savedat_cancel();
			return;
		}

		for(i=0; i<video_size; i++) {
			avi_read_frame_video(avi, i);
			sprintf(arq, "VIDEO%06d", i);
			savedat_insert_object(avi->avi_s[avi->video_stream]->buffer, avi->avi_s[avi->video_stream]->frame_size, arq, "m4v");
			// para cancelar o salvamento no meio
			if(salva_cb()) {
				savedat_cancel();
				return;
			}
		} // for

		// terminha a cria��o do datafile e salva ele
		savedat_close(salva_cb);
	}
}


static void progresso(int n, int max)
{
	int x1, y1, x2, y2, barra1;
	char *msg;
	BITMAP *buffer;

	// seleciona a mensagem apropriada
	if(n == 0)
		msg = prog_msg[0];
	else if(n == 1)
		msg = prog_msg[1];
	else if(n <= max / 2)
		msg = prog_msg[2];
	else
		msg = prog_msg[3];

	// cria buffer
	buffer = create_bitmap(SCREEN_W, 44);
	clear_to_color(buffer, CB0);

	// calcula posi��es e porcentagem
	x1 = (SCREEN_W / 2) - (SCREEN_W * 0.35) + 1;
	y1 = 12;
	y2 = 42;
	x2 = (SCREEN_W / 2) + (SCREEN_W * 0.35) - 1;
	barra1 = x1 + ((float)n / max) * (x2-x1);

	// desenha barra de progresso
	acquire_bitmap(buffer);
	rect(buffer, x1-1, y1-1, x2+1, y2+1, CF1);
	rectfill(buffer, x1, y1, barra1, y2, CB1);
	rectfill(buffer, barra1+1, y1, x2, y2, CB2);
	text_mode(-1);
	textprintf_centre(buffer, font, SCREEN_W/2, 23, CF1, "%3.1f %%", 100*(float)n/max);

	// imprime mensagem
	textout_centre(buffer, font, msg, SCREEN_W / 2, 0, CF1);

	acquire_screen();
	scare_mouse();
	blit(buffer, screen, 0, 0, 0, SCREEN_H/2 - buffer->h/2, buffer->w, buffer->h);
	unscare_mouse();
	release_screen();

	release_bitmap(buffer);
	destroy_bitmap(buffer);
	text_mode(CB0);
}


static void toca_wav(AVI_MOVIE *avi)
{
	SAMPLE *wav;
	int voice;

	wav = gera_sample(avi);
	if(!wav) {
		alert("Isn't possible to reproduce audio!", "", "", "OK", NULL, 13, 0);
		return;
	}

	// se tudo deu certo, o sample foi criado e agora � s� tocar
	voice = allocate_voice(wav);
	voice_start(voice);
	while( (voice_get_position(voice) != -1) && (!key[KEY_ESC]) )
		;
	deallocate_voice(voice);
	destroy_sample(wav);
}


static SAMPLE *gera_sample(AVI_MOVIE *avi)
{
	SAMPLE *wav;
	int tipo, bits, canais, freq, len;
	AVI_STREAM_FORMAT *sf;
	AVI_CHUNK *ac;
	int index;
	int j;
	short int s;
	int pos;

	// procura pela stream de �udio
	if(avi->audio_stream < 0) {
		return NULL;
	}
	sf = &avi->avi_s[avi->audio_stream]->sf;

	// limpa o conte�do das vari�veis e l� as informa��es
	tipo = bits = freq = len = canais = 0;
	memcpy((void *)&tipo, sf->data, 2);
	memcpy((void *)&canais, sf->data+2, 2);
	memcpy((void *)&freq, sf->data+4, 4);
	memcpy((void *)&bits, sf->data+14, 2);

	// verifica se � v�lido
	if(tipo != AVI_AUDIO_PCM) {
		return NULL;
	}

	// loop para criar o sample
	len = 0;
	for(index = 0; index < avi->avi_s[avi->audio_stream]->ai.nused; index++) {
		// posiciona e l� os dados do avi
		fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[index].offset, SEEK_SET);
		ac = avi_chunk_read_header(avi);
		// atualiza o tamanho
		len += ac->size;
	}

	// cria sample
	len /= canais;
	if(bits == 16)
		len /= 2;
	wav = create_sample(bits, ((canais == 2) ? TRUE : FALSE), freq, len);

	// agora percorre novamente o arquivo e l� os dados do sample
	pos = 0;
	for(index = 0; index < avi->avi_s[avi->audio_stream]->ai.nused; index++) {
		// posiciona e l� os dados do avi
		fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[index].offset, SEEK_SET);
		ac = avi_chunk_read_header(avi);
		// atualiza o tamanho
		if(bits == 8) {
			fread(wav->data+pos, ac->size, 1, avi->avi);
		}
		else {
			for(j=0; j < ac->size/2; j++) {
				fread((void *)&s, 2, 1, avi->avi);
				((signed short*)(wav->data+pos))[j] = s ^ 0x8000;
			}
		}
		// atualiza posi��o dos dados j� lidos
		pos += ac->size;
		avi_chunk_destroy(ac);
	}
	return wav;
}


static void *gera_mp3(AVI_MOVIE *avi, int *tamanho)
{
	void *mp3;
	int tipo, canais, freq, len;
	AVI_STREAM_FORMAT *sf;
	AVI_CHUNK *ac;
	int index;
	int pos;

	// procura pela stream de �udio
	if(avi->audio_stream < 0) {
		return NULL;
	}
	sf = &avi->avi_s[avi->audio_stream]->sf;

	// limpa o conte�do das vari�veis e l� as informa��es
	tipo = freq = len = canais = 0;
	memcpy((void *)&tipo, sf->data, 2);
	memcpy((void *)&canais, sf->data+2, 2);
	memcpy((void *)&freq, sf->data+4, 4);

	// verifica se � v�lido
	if(tipo != AVI_AUDIO_MP3) {
		return NULL;
	}

	// loop para criar o mp3
	len = 0;
	for(index = 0; index < avi->avi_s[avi->audio_stream]->ai.nused; index++) {
		// posiciona e l� os dados do avi
		fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[index].offset, SEEK_SET);
		ac = avi_chunk_read_header(avi);
		// atualiza o tamanho
		len += ac->size;
	}

	// cria sample
	mp3 = malloc(len);
	*tamanho = len;

	// agora percorre novamente o arquivo e l� os dados do mp3
	pos = 0;
	for(index = 0; index < avi->avi_s[avi->audio_stream]->ai.nused; index++) {
		// posiciona e l� os dados do avi
		fseek(avi->avi, avi->movi_offset + avi->avi_s[avi->audio_stream]->ai.aie[index].offset, SEEK_SET);
		ac = avi_chunk_read_header(avi);
		// l� os dados
		fread(mp3+pos, ac->size, 1, avi->avi);
		// atualiza posi��o dos dados j� lidos
		pos += ac->size;
		avi_chunk_destroy(ac);
	}
	return mp3;
}


static int salva_cb(void)
{
	char buf[80];

	prog_n++;
	progresso(prog_n, prog_max);
	if(keypressed()) {
		if((readkey() >> 8) == KEY_ESC) {
			if(alert("Cancel?", "", "", "Yes", "No", 13, 27) == 1) {
				return 1;
			}
		}
	}
	if(prog_n == prog_max) {
		sprintf(buf, "File size: %.1f KBytes", (float)file_datasize/1024);
		alert(buf, "", "", "OK", NULL, 13, 0);
	}
	return 0;
}


// s� troca as cores
static int meu_shadow_box(int msg, DIALOG *d, int c)
{
	d->fg = CF1;
	d->bg = CB1;
	return d_shadow_box_proc(msg, d, c);
}

static int meu_ctext(int msg, DIALOG *d, int c)
{
	d->fg = CF1;
	d->bg = CB1;
	return d_ctext_proc(msg, d, c);
}

static int meu_edit(int msg, DIALOG *d, int c)
{
	if(d->flags & D_GOTFOCUS) {
		d->fg = CF2;
		d->bg = CB3;
	}
	else {
		d->fg = CF1;
		d->bg = CB2;
	}
	return d_edit_proc(msg, d, c);
}

static int meu_button(int msg, DIALOG *d, int c)
{
	if(d->flags & D_GOTFOCUS) {
		d->fg = CF2;
		d->bg = CB3;
	}
	else {
		d->fg = CF1;
		d->bg = CB2;
	}
	return d_button_proc(msg, d, c);
}

static int meu_list(int msg, DIALOG *d, int c)
{
	if(d->flags & D_GOTFOCUS) {
		d->fg = CF2;
		d->bg = CB3;
	}
	else {
		d->fg = CF1;
		d->bg = CB2;
	}
	return d_list_proc(msg, d, c);
}

static int meu_text_list(int msg, DIALOG *d, int c)
{
	if(d->flags & D_GOTFOCUS) {
		d->fg = CF2;
		d->bg = CB3;
	}
	else {
		d->fg = CF1;
		d->bg = CB2;
	}
	return d_text_list_proc(msg, d, c);
}

static int meu_textbox(int msg, DIALOG *d, int c)
{
	if(d->flags & D_GOTFOCUS) {
		d->fg = CF2;
		d->bg = CB3;
	}
	else {
		d->fg = CF1;
		d->bg = CB2;
	}
	return d_textbox_proc(msg, d, c);
}
