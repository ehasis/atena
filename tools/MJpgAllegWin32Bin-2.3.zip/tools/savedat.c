/*												Savedat.c
*
*		Este arquivo faz parte da biblioteca MJpgAlleg (http://mjpgalleg.sf.net)
*
*		Rotinas para salvar dados diretamente para um datafile. Muitas destas 
*	rotinas foram retiradas do arquivo datedit.c, do diret�rio tools do
*	Allegro. Eu apenas reescrevi algumas partes.
*
*	Por:			Eduardo "Dudaskank"
*  Based on:	datedit.c, by Shawn Hargreaves, see Allegro readme.txt for
*					copyright information
*
*	26/9/2002
*		- in�cio
*  22~24/10/2002
*		- inser��o de rotina para salvar sample e um savedat_cancel() para
*		  liberar a mem�ria no caso do usu�rio cancelar a cria��o do datafile
*
*/

#include <string.h>
#include <ctype.h>
#include <allegro.h>
#include <allegro/internal/aintern.h>
#include "savedat.h"


static DATAFILE *_atual = NULL;
static char _arquivo[256];
static char _password[256];
int file_datasize;

static void *savedat_grab_binary(AL_CONST char *filename, int *size);
static void savedat_save_binary(DATAFILE *dat, PACKFILE *f);
static void savedat_save_sample(DATAFILE *dat, PACKFILE *f);
static int savedat_save_object(DATAFILE *dat, PACKFILE *f, int (*cb)(void));
static int savedat_save_datafile(DATAFILE *dat, PACKFILE *f, int (*cb)(void));
static DATAFILE *savedat_makenew_file(void);
static char *savedat_pretty_name(AL_CONST char *name, AL_CONST char *ext, int force_ext);
static int savedat_dat_cmp(AL_CONST void *e1, AL_CONST void *e2);
static void savedat_sort_datafile(DATAFILE *dat);
static int savedat_prop_cmp(AL_CONST void *e1, AL_CONST void *e2);
void savedat_sort_properties(DATAFILE_PROPERTY *prop);
static int savedat_clean_typename(AL_CONST char *type);
static char *savedat_clean_name(AL_CONST char *nome);
static void savedat_set_property(DATAFILE *dat, int type, AL_CONST char *value);
static int savedat_save(DATAFILE *dat, AL_CONST char *name, AL_CONST char *password, int (*cb)(void));



/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Grab raw binary data                                         */
/*  Returns : nothing                                                      */
/*                                                                         */
static void *savedat_grab_binary(AL_CONST char *filename, int *size)
{
	void *mem;
	long sz = file_size(filename);
	PACKFILE *f;

	if (sz <= 0)
		return NULL;

	mem = malloc(sz);

	f = pack_fopen(filename, F_READ);
	if (!f) {
		free(mem);
		return NULL; 
	}

	pack_fread(mem, sz, f);
	pack_fclose(f);

	if (errno) {
		free(mem);
		return NULL;
	}

	*size = sz;
	return mem;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Save raw binary data. Striped most of the arguments of the   */
/*  original save_binary                                                   */
/*  Returns : nothing                                                      */
/*                                                                         */
static void savedat_save_binary(DATAFILE *dat, PACKFILE *f)
{
	pack_fwrite(dat->dat, dat->size, f);
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 23/10/2002                                                   */
/*  Updated : Never.                                                       */
/*  Purpose : Save a sample to datafile. Striped most of the arguments of  */
/*  the original save_sample                                               */
/*  Returns : nothing                                                      */
/*                                                                         */
static void savedat_save_sample(DATAFILE *dat, PACKFILE *f)
{
	SAMPLE *spl = (SAMPLE *)dat->dat;

	pack_mputw((spl->stereo) ? -spl->bits : spl->bits, f);
	pack_mputw(spl->freq, f);
	pack_mputl(spl->len, f);
	if (spl->bits == 8) {
		pack_fwrite(spl->data, spl->len * ((spl->stereo) ? 2 : 1), f);
	}
	else {
		int i;

		for (i=0; i < (int)spl->len * ((spl->stereo) ? 2 : 1); i++) {
			pack_iputw(((unsigned short *)spl->data)[i], f);
		}
	}
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : 24/10/2002                                                   */
/*  Purpose : Save an object data and name. If cb return 1, return 1 too   */
/*  Returns : 1 error, 0 ok                                                */
/*                                                                         */
static int savedat_save_object(DATAFILE *dat, PACKFILE *f, int (*cb)(void))
{
	DATAFILE_PROPERTY *prop;

	prop = dat->prop;
	savedat_sort_properties(prop);

	while ((prop) && (prop->type != DAT_END)) {
		pack_mputl(DAT_PROPERTY, f);
		pack_mputl(prop->type, f);
		pack_mputl(strlen(prop->dat), f);
		pack_fwrite(prop->dat, strlen(prop->dat), f);
		file_datasize += 12 + strlen(prop->dat);
		prop++;
		if (errno)
			return 1;
	}

	pack_mputl(dat->type, f);
	f = pack_fopen_chunk(f, 1);
	file_datasize += 12;

	switch(dat->type) {
		case DAT_SAMPLE :
			savedat_save_sample(dat, f);
		break;
		default:
			savedat_save_binary(dat, f);
		break;
	}

	pack_fclose_chunk(f);

	file_datasize += _packfile_filesize;
	if(cb)
		return cb();
	return 0;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : 24/10/2002                                                   */
/*  Purpose : Save the entire datafile                                     */
/*  Returns : 0 ok, 1 error                                                */
/*                                                                         */
static int savedat_save_datafile(DATAFILE *dat, PACKFILE *f, int (*cb)(void))
{
	int c, size;

	savedat_sort_datafile(dat);

	size = 0;
	while (dat[size].type != DAT_END)
		size++;

	pack_mputl(size, f);

	for (c=0; c<size; c++) {
		if(savedat_save_object(dat+c, f, cb))
			return 1;

		if (errno)
			return 1;
	}
	return 0;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Creates a new datafile                                       */
/*  Returns : A pointer to the new datafile                                */
/*                                                                         */
static DATAFILE *savedat_makenew_file(void)
{
	DATAFILE *dat = _al_malloc(sizeof(DATAFILE));

	dat->dat = NULL;
	dat->type = DAT_END;
	dat->size = 0;
	dat->prop = NULL;

	return dat;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Adds extensions to filenames if they are missing, or changes */
/*            them                                                         */
/*  Returns : A pointer to the new datafile name                           */
/*                                                                         */
/*  */
static char *savedat_pretty_name(AL_CONST char *name, AL_CONST char *ext, int force_ext)
{
	static char buf[256];
	char *s;

	strcpy(buf, name);

	s = get_extension(buf);
	if ((s > buf) && (*(s-1)=='.')) {
		if (force_ext)
			strcpy(s, ext);
	}
	else {
		*s = '.';
		strcpy(s+1, ext);
	}

	fix_filename_case(buf);
	return buf;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Qsort callback for comparing datafile objects                */
/*  Returns : = 0 if equal, < 0 if e1 < e2, > 0 if e1 > e2                 */
/*                                                                         */
static int savedat_dat_cmp(AL_CONST void *e1, AL_CONST void *e2)
{
	DATAFILE *d1 = (DATAFILE *)e1;
	DATAFILE *d2 = (DATAFILE *)e2;

	return stricmp(get_datafile_property((AL_CONST DATAFILE*)d1, DAT_NAME), get_datafile_property((AL_CONST DATAFILE*)d2, DAT_NAME));
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Sorts a datafile                                             */
/*  Returns : Nothing                                                      */
/*                                                                         */
static void savedat_sort_datafile(DATAFILE *dat)
{
	int len;

	if (dat) {
		len = 0;
		while (dat[len].type != DAT_END)
			len++;

		if (len > 1)
			qsort(dat, len, sizeof(DATAFILE), savedat_dat_cmp);
	}
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Qsort callback for comparing datafile properties             */
/*  Returns : = 0 if equal, < 0 if e1 < e2, > 0 if e1 > e2                 */
/*                                                                         */
static int savedat_prop_cmp(AL_CONST void *e1, AL_CONST void *e2)
{
	DATAFILE_PROPERTY *p1 = (DATAFILE_PROPERTY *)e1;
	DATAFILE_PROPERTY *p2 = (DATAFILE_PROPERTY *)e2;

	return p1->type - p2->type;
}



/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : sorts a list of object properties                            */
/*  Returns : Nothing                                                      */
/*                                                                         */
void savedat_sort_properties(DATAFILE_PROPERTY *prop)
{
	int len;

	if (prop) {
		len = 0;
		while (prop[len].type != DAT_END)
			len++;

		if (len > 1)
		qsort(prop, len, sizeof(DATAFILE_PROPERTY), savedat_prop_cmp);
	}
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Cleans up an object type string, and packs it                */
/*  Returns : The packed type                                              */
/*                                                                         */
static int savedat_clean_typename(AL_CONST char *type)
{
	int c1, c2, c3, c4;

	if (!type)
		return 0;

	c1 = (*type) ? utoupper(*(type++)) : ' ';
	c2 = (*type) ? utoupper(*(type++)) : ' ';
	c3 = (*type) ? utoupper(*(type++)) : ' ';
	c4 = (*type) ? utoupper(*(type++)) : ' ';

	return DAT_ID(c1, c2, c3, c4);
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Cleans up an object name string                              */
/*  Returns : The new name                                                 */
/*                                                                         */
static char *savedat_clean_name(AL_CONST char *nome)
{
	static char str[256];
	char *s, *r;

	s = get_filename(nome);
	r = str;
	while(*s) {
		if( (!isalnum(*s)) && (*s != '_') )
			*r = '_';
		else
			*r = *s;
		r++;
		s++;
	}
	*r = 0;
	return str;
}



/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Sets an object property string                               */
/*  Returns : Nothing                                                      */
/*                                                                         */
static void savedat_set_property(DATAFILE *dat, int type, AL_CONST char *value)
{
	int i, size, pos;

	if (dat->prop) {
		pos = -1;
		for (size=0; dat->prop[size].type != DAT_END; size++)
			if (dat->prop[size].type == type)
				pos = size;

		if ((value) && (strlen(value) > 0)) {
			if (pos >= 0) {
				dat->prop[pos].dat = _al_realloc(dat->prop[pos].dat, strlen(value)+1);
				strcpy(dat->prop[pos].dat, value);
			}
			else {
				dat->prop = _al_realloc(dat->prop, sizeof(DATAFILE_PROPERTY)*(size+2));
				dat->prop[size+1] = dat->prop[size];
				dat->prop[size].type = type;
				dat->prop[size].dat = _al_malloc(strlen(value)+1);
				strcpy(dat->prop[size].dat, value);
			}
		}
		else {
			if (pos >= 0) {
				_al_free(dat->prop[pos].dat);
				for (i=pos; i<size; i++)
					dat->prop[i] = dat->prop[i+1];
				dat->prop = _al_realloc(dat->prop, sizeof(DATAFILE_PROPERTY)*size);
			}
		}
	}
	else {
		if ((value) && (strlen(value) > 0)) {
			dat->prop = _al_malloc(sizeof(DATAFILE_PROPERTY) * 2);
			dat->prop[0].type = type;
			dat->prop[0].dat = _al_malloc(strlen(value)+1);
			strcpy(dat->prop[0].dat, value);
			dat->prop[1].type = DAT_END;
			dat->prop[1].dat = NULL;
		}
	}
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : 24/10/2002                                                   */
/*  Purpose : Save the datafile to the file with the given password        */
/*  Returns : 1 on error, 0 on success                                     */
/*                                                                         */
static int savedat_save(DATAFILE *dat, AL_CONST char *name, AL_CONST char *password, int (*cb)(void))
{
	char pretty_name[256];
	PACKFILE *f;
	int r = 0;

	packfile_password(password);

	strcpy(pretty_name,savedat_pretty_name(name, "dat", 1));

	f = pack_fopen(pretty_name, F_WRITE_NOPACK);

	if (f) {
		pack_mputl(DAT_MAGIC, f);
		file_datasize = 12;

		r = savedat_save_datafile(dat, f, cb);

		pack_fclose(f); 
	}

	if (errno || r) {
		delete_file(pretty_name);
		packfile_password(NULL);
		return 1;
	}

	packfile_password(NULL);
	return 0;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Start the creation of a new datafile                         */
/*  Returns : 1 on error, 0 on success                                     */
/*                                                                         */
int savedat_start(AL_CONST char *arquivo, AL_CONST char *password)
{
	if ( (!arquivo) || (!strlen(arquivo)) ) {
		return 1;
	}
	strcpy(_arquivo, arquivo);
	if ( (!password) || (!strlen(password)) ) {
		strcpy(_password, "");
	}
	else {
		strcpy(_arquivo, arquivo);
	}

	// se existe um datafile na mem�ria, destr�i ele
	if (_atual != NULL) {
		unload_datafile(_atual);
		_atual = NULL;
	}

	// cria o novo datafile
	_atual = savedat_makenew_file();

	return 0;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 26/9/2002                                                    */
/*  Updated : 24/10/2002                                                   */
/*  Purpose : Close the datafile, writing it to the file and unloading the */
/*            datafile from the memory, and call 'cb' for each object. If  */
/*            cb return 1, cancel the save                                 */
/*  Returns : 1 on error, 0 on success                                     */
/*                                                                         */
int savedat_close(int (*cb)(void))
{
	int r;
	r = savedat_save(_atual, _arquivo, _password, cb);
	if(_atual) {
		unload_datafile(_atual);
		strcpy(_arquivo, "");
		strcpy(_password, "");
		_atual = NULL;
	}
	return r;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 27/9/2002                                                    */
/*  Updated : 24/10/2002                                                   */
/*  Purpose : Insert a new item in the '_atual' datafile                   */
/*  Returns : 1 on error, 0 on success                                     */
/*                                                                         */
int savedat_insert_object(void *data, int size, AL_CONST char *name, AL_CONST char *type)
{
	int i;
	char nome[256];
	// insere no datafile '_atual'
	for(i=0; _atual[i].type != DAT_END; i++)
		;
	_atual = _al_realloc(_atual, sizeof(DATAFILE)*(i+2));
	_atual[i+1] = _atual[i];
	_atual[i].type = savedat_clean_typename(type);
	switch(_atual[i].type) {
		case DAT_SAMPLE :
			// precisa criar o sample primeiro
			{
				SAMPLE *wav = (SAMPLE *)data;
				_atual[i].dat = (void *)create_sample( wav->bits, wav->stereo, wav->freq, wav->len );
				size = wav->len * ( wav->bits / 8 ) * ( (wav->stereo != FALSE) ? 2 : 1);
				memcpy( ((SAMPLE *)_atual[i].dat)->data, wav->data, size);
				size += sizeof(SAMPLE);
			}
		break;
		default :
			_atual[i].dat = _al_malloc(size);
			if(!_atual[i].dat)
				return 1;
			memcpy(_atual[i].dat, data, size);
		break;
	}
	_atual[i].size = size;
	_atual[i].prop = NULL;
	strcpy(nome, savedat_clean_name(name));
	savedat_set_property(&_atual[i], DAT_NAME, nome);
	return 0;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 27/9/2002                                                    */
/*  Updated : Never.                                                       */
/*  Purpose : Load and insert a file in '_atual' datafile                  */
/*  Returns : 1 on error, 0 on success                                     */
/*                                                                         */
int savedat_insert_file(AL_CONST char *arq, AL_CONST char *type)
{
	void *data;
	int size, r;

	data = savedat_grab_binary(arq, &size);
	if(!data)
		return 1;

	r = savedat_insert_object(data, size, arq, type);
	free(data);

	return r;
}


/*                                                                         */
/*  Author  : Eduardo "Dudaskank"                                          */
/*  Created : 24/10/2002                                                   */
/*  Updated : Never.                                                       */
/*  Purpose : Cancel the creation of the datafile and free the memory      */
/*  Returns : Nothing                                                      */
/*                                                                         */
void savedat_cancel(void)
{
	if(_atual) {
		unload_datafile(_atual);
		strcpy(_arquivo, "");
		strcpy(_password, "");
		_atual = NULL;
	}
}


#if 0

int main(void)
{
	char arq[] = "teste000.dat";
	char str[] = "Shoryuken";
	int i;

	allegro_init();
	savedat_start(arq, NULL);
	for(i=0; i<1000; i++) {
		sprintf(arq, "string%04d", i);
		savedat_insert_object(str, strlen(str)+1, arq, "str");
	}
	savedat_insert_file("savedat.h", "data");
	savedat_close();
	allegro_message("Pronto!");
	return 0;
}
END_OF_MAIN();

#endif
