#ifndef _SAVEDAT_H
#define _SAVEDAT_H

extern int file_datasize;

int savedat_start(AL_CONST char *arquivo, AL_CONST char *password);
int savedat_close(int (*cb)(void));
int savedat_insert_object(void *data, int size, AL_CONST char *name, AL_CONST char *type);
int savedat_insert_file(AL_CONST char *arq, AL_CONST char *type);
void savedat_cancel(void);

#endif
